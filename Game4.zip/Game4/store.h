
#ifndef STORE_H
#define STORE_H


#include<QLabel>
#include <QMainWindow>
#include"sharecode.h"
#include<QTimer>

typedef void (*FunctionPointer)(int);
class Store:public MyWidget
{
    Q_OBJECT
public:
    Store(QWidget *parent = nullptr,int* equipment=nullptr,int* money=nullptr,Equipment** equipment_=nullptr);
    QPushButton* buy[6];
    QPushButton* good[6];
    QPushButton* cancel;
    QLabel* label[6];
    QString price[6];
    int* things;
    int* money;
    QLabel *buysuc;
    QLabel *buyfai;
    Equipment** equip;
    QTimer* timer;
    QLabel* showmoney;
    // 创建一个函数指针容器 QVector<FunctionPointer>


    // 向容器中添加函数指针


    void deal1(){
        if(*money>=equip[0]->price){
            (*money)-=equip[0]->price;
            buysuc->show();
            things[0]++;
        }
        else{
            buyfai->show();

        }
        emit clickbuy();

    }
    void deal2(){
        if(*money>=equip[1]->price){
            (*money)-=equip[1]->price;
            buysuc->show();
            things[1]++;
        }
        else{
            buyfai->show();

        }
        emit clickbuy();

    }
    void deal3(){
        if(*money>=equip[2]->price){
            (*money)-=equip[2]->price;
            buysuc->show();
            things[2]++;
        }
        else{
            buyfai->show();

        }
        emit clickbuy();

    }
    void deal4(){
        if(*money>=equip[3]->price){
            (*money)-=equip[3]->price;
            buysuc->show();
            things[3]++;
        }
        else{
            buyfai->show();

        }
        emit clickbuy();

    }
    void deal5(){
        if(*money>=equip[4]->price){
            (*money)-=equip[4]->price;
            buysuc->show();
            things[4]++;
        }
        else{
            buyfai->show();

        }
        emit clickbuy();

    }
    void deal6(){
        if(*money>=equip[5]->price){
            (*money)-=equip[5]->price;
            buysuc->show();
            things[5]++;
        }
        else{
            buyfai->show();

        }
        emit clickbuy();

    }
    void starttimer(){
        timer->start(1000);
    }
    void resetshowmoney(){
        showmoney->setText(QString("%1").arg(*money));
    }
signals:
    void clickbuy();



};

#endif // STORE_H
