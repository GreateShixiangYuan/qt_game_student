
#ifndef STOPWINDOW_H
#define STOPWINDOW_H




class StopWindow
{
public:
    StopWindow();
};

#endif // STOPWINDOW_H
