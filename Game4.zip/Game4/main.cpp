#include <QApplication>
#include"myview.h"
#include"mainwindow.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow mainwindow;
 //   QObject::connect(mainwindow.w4->end,&QPushButton::clicked,&a,&QApplication::quit);
    mainwindow.show();
    return a.exec();
}
