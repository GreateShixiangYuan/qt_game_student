
#include "bullet.h"

Bullet::Bullet(QString filename,QPointF direction_,QGraphicsScene*scene_):QpixmapItem(filename,scene_),direction(direction_)
{
    crash=0;
    speed=30;
    setData(ObjectType,BulletType);
}

