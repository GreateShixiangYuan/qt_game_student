
#ifndef CHARACTERWINDOW_H
#define CHARACTERWINDOW_H
#include <QMainWindow>
#include <QVBoxLayout>   // 如果使用 QVBoxLayout 布局
#include <QHBoxLayout>   // 如果使用 QHBoxLayout 布局
#include <QGridLayout>   // 如果使用 QGridLayout 布局
#include <QLabel>        // 如果需要添加标签控件
#include <QPushButton>   // 如果需要添加按钮控件
#include <QLineEdit>     // 如果需要添加单行编辑框控件
#include <QTextEdit>
#include<QPixmap>
#include"scene.h"
#include"levelwindow.h"
class CharacterWindow:public QMainWindow
{
public:
    CharacterWindow(QWidget *parent = nullptr,Scene* scene_=nullptr);
    QFrame* frame;
    Scene* scene;
    QString s[3];
    QLabel *label1;
    QLabel *label2;
    QPushButton *pix;
    QPushButton* pixl;
    QPushButton* pixr;
    QPixmap *pixmap[3];
    int pos[3];
    QPushButton* switchl;
    QPushButton* switchr;
    QPushButton* sure;
    QPushButton* back;

    LevelWindow* setlevel;
    void changel();
    void changer();
    void setcharacter(){
        scene->setweapon(pos[1]);
        setlevel=new LevelWindow(this,scene);
        setlevel->show();
    }
    void destro(){
        delete scene;
        delete this;
    }

    ~CharacterWindow(){
        delete label1;
        delete label2;
        delete frame;
        delete pix;
        delete pixl;
        delete pixr;
        for (int i = 0; i < 3; i++) {
            delete pixmap[i];
            pixmap[i] = nullptr;
        }
        delete switchl;
        delete switchr;
        delete sure;
        delete back;
        if(setlevel!=nullptr){
            delete setlevel;
        }
    }

};
#endif // CHARACTERWINDOW_H
