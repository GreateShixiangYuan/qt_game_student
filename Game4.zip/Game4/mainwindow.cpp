
#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    sl=nullptr;
    view=nullptr;
    resize(800,600);
    setWindowTitle("幸存者游戏");
    setWindowIcon(QIcon("D:\\game\\Game4\\icon.png"));
    QPalette palette;
    palette.setBrush(QPalette::Window,QBrush(QPixmap("D:\\game\\Game4\\photo1.jpeg")));
    setPalette(palette);
    QPixmap pixmap("D:\\game\\Game4\\buttonback.png");
    start=new QPushButton(this);
    start->setGeometry(300,300,150,50);
    QPalette pal=start->palette();
    pal.setBrush(QPalette::Button, pixmap.scaled(start->width(),start->height()));
    start->setAutoFillBackground(true);
    start->setPalette(pal);
    QFont font("宋体",25,QFont::Bold);
    start->setFont(font);
    start->setText("新的游戏");
    start->setFlat(true);
    start->setStyleSheet("color:white;");
    start->setFocusPolicy(Qt::NoFocus);

    load=new QPushButton(this);
    load->setGeometry(300,370,150,50);
    QPalette pal2=load->palette();
    pal2.setBrush(QPalette::Button, pixmap.scaled(load->width(),load->height()));
    load->setAutoFillBackground(true);
    load->setPalette(pal2);
    load->setFont(font);
    load->setText("加载存档");
    load->setFlat(true);
    load->setFocusPolicy(Qt::NoFocus);
    load->setStyleSheet("color:white;");
    view=new MyView(this);
    view->hide();
    connect(view->home->outgame,&QPushButton::clicked,this,&MainWindow::endgame);
    connect(start,&QPushButton::clicked,this,&MainWindow::startclick);
    connect(load,&QPushButton::clicked,this,&MainWindow::loaddata);


}

void MainWindow::closeEvent(QCloseEvent* event) {
    if(view!=nullptr){
        if(sl==nullptr){
            sl=new SL(nullptr,view->home);
        }
            sl->state=1;
            sl->show();
            connect(sl,&SL::store,sl,&SL::deletethis);
    }
}
void MainWindow::loaddata(){   
    sl=new SL(nullptr,view->home);
    sl->show();
    connect(sl,&SL::load,sl,&SL::hide);
    connect(sl,&SL::load,view,&MyView::show);
}
void MainWindow::startclick(){
    view->show();
}
