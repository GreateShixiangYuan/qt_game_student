
#ifndef WEAPON_H
#define WEAPON_H

#include"qpixmapitem.h"
#include<QGraphicsScene>
//属性：剑气伤害，范围距离，吸血
//attack1
class Weapon:public QpixmapItem
{
public:
    Weapon(QString filename,QGraphicsScene*);
    void advance(int);
    void up1(){
        attack2+=700;
    }
    void up2(){
        naofweapon[1]+=4;
    }
    void up3(){
        xx1+=0.05;
        xx2+=0.05;
    }
    void setweaponnature(int dj){
        attack1+=dj*100;
        attack2+=dj*50;
    }
};

#endif // WEAPON_H
