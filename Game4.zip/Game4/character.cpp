
#include "character.h"

Character::Character(QString filename,QGraphicsScene* scene_):QpixmapItem(filename,scene_),direction(0,0)
{
    W=S=A=D=false;
    dengji=1;
    changes=0;
    experience=0;
    explimit=1000;
    setTransformOriginPoint(pixmap.width()/2,pixmap.height()/2);
    setFlags(QGraphicsItem::ItemIsFocusable);
    setData(ObjectType, CharacterType);
    updiscribe[0]="增加生命";
    updiscribe[1]="增加攻击";
    updiscribe[2]="增加防御";
    updiscribe[3]="增加穿透";
    updiscribe[4]="增加暴击率";
    updiscribe[5]="增加暴击效果";
    updiscribe[6]="增加移动速度";

}
void Character::makeit1(){
    if(direction!=QPointF(0,0))
    direction=direction/qSqrt(direction.x()*direction.x()+direction.y()*direction.y());
}
void Character::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    QGraphicsPixmapItem::paint(painter, option, widget); // 先绘制角色形象

    qreal progressRatio = nowhp / hp; // 计算血量比例

    QRectF rect(QPointF(0, 0), pixmap.size());

    // 绘制底层背景
    qreal barHeight = 10;
    qreal barWidth = rect.width();
    QRectF barRect(0, -12, barWidth, barHeight);
    painter->setPen(Qt::NoPen);
    painter->setBrush(Qt::gray);
    painter->drawRect(barRect);

    // 绘制血条
    painter->setBrush(Qt::green);
    painter->drawRect(barRect.adjusted(0, 0, -((1 - progressRatio) * barWidth), 0));

    // 在血条上画黑色竖线，血越厚竖线越密
    int lineCount = (int)(hp/1000);
    qreal lineWidth =barWidth / lineCount; // 计算每个竖线的间隔长度
    QPen linePen(Qt::black, 0.5); // 竖线颜色和宽度
    painter->setPen(linePen);
    for (int i = 1; i < lineCount; ++i) {
    painter->drawLine( i * lineWidth, -12, i * lineWidth,-7 );
    }

    QRectF circleRect(barRect.left() -15, -17, 18, 18);
    QRectF rect2(barRect.left() -17, -19, 22, 22);
    painter->setBrush(Qt::gray);
    painter->drawEllipse(rect2);
    painter->setBrush(Qt::black);
    painter->drawEllipse(circleRect);
    painter->setPen(QPen(Qt::white, 2));
    painter->setFont(QFont("Arial", 8));
    painter->drawText(circleRect, Qt::AlignCenter, QString("%1").arg(dengji));
    qreal progressAngle = experience / explimit * 360.0; // 计
    painter->setPen(QPen(Qt::red, 4));
    painter->drawArc(rect2, 90 * 16, -progressAngle * 16);



}
void Character::upgrade(){
    hp*=1.2;
    nowhp=hp;
    atk*=1.2;
    dengji++;
    changes++;
    experience=0;
    explimit*=1.2;
}
void Character::up1(){
    hp+=3000;
}
void Character::up2(){
    atk+=0.2;
}
void Character::up3(){
    defense+=500;
}
void Character::up4(){
    penetration+=400;
}
void Character::up5(){
    strikerate+=10;
}
void Character::up6(){
    strikeeffect+=50;
}
void Character::up7(){
    speed+=2;
}
void Character::useup(){
    switch (meminfo) {
    case 0:
    up1();
    break;
    case 1:
    up2();
    break;
    case 2:
    up3();
    break;
    case 3:
    up4();
    break;
    case 4:
    up5();
    break;
    case 5:
    up6();
    break;
    case 6:
    up7();
    break;
    case 7:
    weapon->up1();
    break;
    case 8:
    weapon->up2();
    break;
    case 9:
    weapon->up3();
    break;
    default:
    break;
    }
}

