
#ifndef LEVELWINDOW_H
#define LEVELWINDOW_H

#include"scene.h"
#include <QMainWindow>
#include<QPushButton>

class LevelWindow:public QMainWindow
{
    Q_OBJECT
public:
    LevelWindow(QWidget *parent = nullptr,Scene* scene_=nullptr);
    QPushButton* easy;
    QPushButton* middle;
    QPushButton* difficult;
    QPushButton* back;
    Scene* scene;

    void setlevel1(){
        scene->setdifficult(0);
        scene->start();

    }
    void setlevel2(){
        scene->setdifficult(1);
        scene->start();
    }
    void setlevel3(){
        scene->setdifficult(2);
        scene->start();
    }
    void dealback(){
        delete this;
    }
    ~LevelWindow(){
        delete easy;
        delete middle;
        delete difficult;
        delete back;

    }
signals:
    void sure();

};

#endif // LEVELWINDOW_H
