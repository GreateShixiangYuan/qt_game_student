
#include "enemy.h"

Enemy::Enemy(QString filename,QGraphicsScene* scene_):QpixmapItem(filename,scene_),destination(0,0)
{
    targeted=false;
    hp=2000;
    nowhp=hp;
    speed=3;
    atk=400;
    direction=QPointF(-1,0);
    setFlag(QGraphicsItem::ItemIsMovable, true);
    setData(ObjectType, EnemyType);
    setTransformOriginPoint(pixmap.width()/2,pixmap.height()/2);
    ifcontrol=false;
    gapx=0;
    gapy=0;
    defense=500;
}

void Enemy::shoot(){
    Bullet* bullet=new Bullet("D:\\game\\Game4\\bullet.png",direction,scene);
    scene->addItem(bullet);
    bullet->setPos(pos()+QPointF(pixmap.width()/2,pixmap.height()/2)+direction*pixmap.width());
    qreal angle = qRadiansToDegrees(qAtan2(-direction.y(), -direction.x()));
    bullet->setRotation(angle);
}
void Enemy::resetdirection(){
    qreal dx=destination.x()-x();
    qreal dy=destination.y()-y();
    qreal distance=qSqrt(dx*dx+dy*dy);
    destination.setX(dx/distance);
    destination.setY(dy/distance);

}
void Enemy::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    QGraphicsPixmapItem::paint(painter, option, widget); // 先绘制角色形象
    if(nowhp<0)
        nowhp=0;
    qreal progressRatio = nowhp / hp; // 计算血量比例

    QRectF rect(QPointF(0, 0), pixmap.size());
    qreal barHeight = 10;
    qreal barWidth = rect.width();
    QRectF barRect(0, -10, barWidth, barHeight);
    painter->setPen(Qt::NoPen);

    painter->setBrush(Qt::gray);
    painter->drawRect(barRect); // 绘制底层背景

    painter->setBrush(QColor(55, 200, 250)); // 设置血条颜色
    painter->drawRect(barRect.adjusted(0, 0, -((1 - progressRatio) * barWidth), 0)); // 随血量绘制血条
    int lineCount = (int)(hp/1000);
    qreal lineWidth =barWidth / lineCount; // 计算每个竖线的间隔长度
    QPen linePen(Qt::black, 0.5); // 竖线颜色和宽度
    painter->setPen(linePen);
    for (int i = 1; i < lineCount; ++i) {
        painter->drawLine( i * lineWidth, -10, i * lineWidth,0 );
    }
}



Enemy2::Enemy2(QGraphicsScene* scene_):QpixmapItem("D:\\game\\Game4\\monster2.png",scene_),destination(0,0)
{
    targeted=false;
    hp=5000;
    nowhp=hp;
    speed=4;
    atk=1000;
    direction=QPointF(-1,0);
    setFlag(QGraphicsItem::ItemIsMovable, true);
    setData(ObjectType, MonsterType);
    setTransformOriginPoint(pixmap.width()/2,pixmap.height()/2);
    ifcontrol=false;
    gapx=0;
    gapy=0;
    defense=1500;
}


void Enemy2::resetdirection(){
    qreal dx=destination.x()-x();
    qreal dy=destination.y()-y();
    qreal distance=qSqrt(dx*dx+dy*dy);
    destination.setX(dx/distance);
    destination.setY(dy/distance);

}
void Enemy2::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    QGraphicsPixmapItem::paint(painter, option, widget); // 先绘制角色形象
    if(nowhp<0)
        nowhp=0;
    qreal progressRatio = nowhp / hp; // 计算血量比例

    QRectF rect(QPointF(0, 0), pixmap.size());
    qreal barHeight = 10;
    qreal barWidth = rect.width();
    QRectF barRect(0, -10, barWidth, barHeight);
    painter->setPen(Qt::NoPen);

    painter->setBrush(Qt::gray);
    painter->drawRect(barRect); // 绘制底层背景

    painter->setBrush(QColor(55, 200, 250)); // 设置血条颜色
    painter->drawRect(barRect.adjusted(0, 0, -((1 - progressRatio) * barWidth), 0)); // 随血量绘制血条
    int lineCount = (int)(hp/1000);
    qreal lineWidth =barWidth / lineCount; // 计算每个竖线的间隔长度
    QPen linePen(Qt::black, 0.5); // 竖线颜色和宽度
    painter->setPen(linePen);
    for (int i = 1; i < lineCount; ++i) {
        painter->drawLine( i * lineWidth, -10, i * lineWidth,0 );
    }
}
