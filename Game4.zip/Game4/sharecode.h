
#ifndef SHARECODE_H
#define SHARECODE_H
#include<QPushButton>
#include<QLabel>
#include<QGraphicsScene>
#include<QRandomGenerator>
#include<QGraphicsPixmapItem>
#include<QGraphicsItem>
#include <QtWidgets>
class Equipment:public QPushButton{
public:
    Equipment(QPixmap pix,QString name_,QString intr,int price_,QWidget* parent,qreal* na):QPushButton(parent){
        pixmap=pix;
        name=name_;
        introduce=intr;
        price=price_;
        QPalette palette;
        palette.setBrush(QPalette::Button,pixmap);
        setAutoFillBackground(true);
        setPalette(palette);
        setFlat(true);
        setFocusPolicy(Qt::NoFocus);
        setToolTip(introduce);
        for(int i=0;i<8;i++){
            nature[i]=na[i];
        }

    }
    QString name;
    QString introduce;
    int price;
    QPixmap pixmap;
    qreal nature[8];
};

//commonwindow


class MyWidget : public QWidget {
public:
    MyWidget(QWidget *parent = nullptr) : QWidget(parent) {
        resize(640, 480);
        setWindowFlags(Qt::FramelessWindowHint);
        setAttribute(Qt::WA_TransparentForMouseEvents);
    }

};

enum ObjectTypeEnu {
    ObjectType2 = QGraphicsItem::UserType + 1,
    Chara,
    Obsta,
    Borde
};


class Jues:public QGraphicsPixmapItem{
public:
    Jues(QString f1,QGraphicsScene* scene_,int* nat ):QGraphicsPixmapItem(nullptr){
        nature=new int[13];
        pixmap.load(f1);
        pixmapreverse=pixmap.transformed(QTransform().scale(-1,1));
        setPixmap(pixmap);
        setShapeMode(QGraphicsPixmapItem::MaskShape);
        scene_->addItem(this);
        direction=QPointF(1,0);
        generator= QRandomGenerator::securelySeeded();
        count=0;
        type=1;
        for(int i=0;i<12;i++){
            nature[i]=nat[i];
        }
        nature[12]=0;
    }
    int count;
    qreal speed;
    QPixmap pixmap;
    QPixmap pixmapreverse;
    QPointF direction;
    QRandomGenerator generator;
    int type;
    int *nature;//0:hp 1:def 2:atk 3:atksp 4:pet 5:skr 6:ske 7:spd//8:hand,9:shoes
    //10 head,11 body,
    //12 weaponlevel;
        bool movable(){
        QList<QGraphicsItem*> items = collidingItems();
        for(auto i:items){
            if(i->data(ObjectType2) == Obsta)
                return false;
        }
        return true;

    }
    void advance(int){
        count++;
        if(count>10000000){
            count=0;
        }

        if(count%70==0){
            switch (generator.bounded(4)) {
            case 0:
                direction=QPointF(0,1);
                break;
            case 1:
                direction= QPointF(0,-1);
                break;
            case 3:
                direction=QPointF(1,0);
                break;
            case 2:
                direction=QPointF(-1,0);
                break;
            default:
                direction= QPointF(0,0);
            }
        }
        else if(count%140>70){

        }
        else{
            QPointF target(pos()+direction);
            setPos(target);
            if(!movable())
            {
                setPos(pos()-2*direction);
                if(movable())
                    direction*=-1;
                else{
                    setPos(pos()+direction);
                }
            }
        }
        int temp=1;
        if(direction.x()<0){
            temp=-1;
        }
        if(temp!=type){
            type=temp;
            if(type>0){
                setPixmap(pixmap);
            }
            else{
                setPixmap(pixmapreverse);
            }
        }
    }


};
class smallwindow:public QObject{
    Q_OBJECT
public:
    QList<QLabel*> labellist;
    QList<QPushButton*> buttonlist;
    QWidget* parent;
    QPushButton* back;
    QLabel* addlabel(){
        QLabel* temp=new QLabel(parent);

        labellist.append(temp);
        return temp;
    }
    QPushButton* addbutton(){
        QPushButton* temp=new QPushButton(parent);

        buttonlist.append(temp);
        return temp;
    }
    smallwindow(QWidget* parent_){
        parent=parent_;
        back=new QPushButton(parent);
        QObject::connect(back,&QPushButton::clicked,this,&smallwindow::destroythis);
    }
    ~smallwindow(){
        delete back;
        for(auto i:labellist){
            delete i;
        }
        for(auto i:buttonlist){
            delete i;
        }
    }
    void destroythis(){
        delete this;
    }

};
/*
void loaddata(int* money,int* things){
    QFile file("savegame.dat");

    if (file.open(QIODevice::ReadOnly)) {
        QDataStream stream(&file);
        stream >> *money;
        for (int i = 0; i < 6; ++i) {
            stream >> things[i];
        }

        file.close();
    }
}
*/
#endif // SHARECODE_H
