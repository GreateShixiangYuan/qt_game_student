
#include "qpixmapitem.h"
