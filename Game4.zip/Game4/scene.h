
#ifndef SCENE_H
#define SCENE_H
#include<QRandomGenerator>
#include<QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsRectItem>
#include<QPixmap>
#include "character.h"
#include "enemy.h"
#include"bullet.h"
#include<QTimer>
#include"weapon.h"
#include"weapon2.h"
#include"weapon3.h"
#include<QThread>
#include <QtCore/qmath.h>
//static int hpc=5000;
class Scene:public QGraphicsScene
{
    Q_OBJECT
public slots:


    void check();
    public:
    QpixmapItem* weapon1;
    Character *character;
    QList<QGraphicsPixmapItem*> obstacle;
    Enemy* enemy[10];
    QTimer* timer;
    int difficulty;
    int* nature;
    int timelimit;
    Scene(QObject *parent = nullptr);
    void drawmap();
    void keyPressEvent(QKeyEvent* event);
    void keyReleaseEvent(QKeyEvent* event);
    void setobstacle(int x,int y);
    static QPointF arr();
    void setweapon(int);
    void setdifficult(int);
    void renew();
    void start(){
        renew();
        emit startgame();
        renew();
    }
    void choosenature();
    ~Scene(){
        for(auto i:obstacle){
            delete i;
        }
        delete timer;

    }
signals:
    void die();
    void upgrade();
    void realmove();
    void gothrough1s();
    void startgame();
    void victory();
};

#endif // SCENE_H
