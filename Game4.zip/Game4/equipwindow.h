
#ifndef EQUIPWINDOW_H
#define EQUIPWINDOW_H

#include "sharecode.h"
#include<QLabel>
#include <QMainWindow>
#include<QPushButton>

class EquipWindow:public MyWidget
{
    Q_OBJECT
public:
    EquipWindow(QWidget *parent = nullptr,Jues** c=nullptr,Equipment** e=nullptr,int num=0,int* things=nullptr,int* mon=nullptr);
    Jues** c;
    Equipment** equipment;
    QPushButton* switchc;
    QPushButton* upg;
    QLabel* showc;
    QLabel* showdj;
    QPixmap* equipback;
    int* nowc;
    int* things;
    int* money;
    QPushButton* back;
    QPushButton* showcase;
    int nowe;
    void upgrade(){
        if(*money>=500){
            (*money)-=500;
            c[*nowc]->nature[12]++;
            showdj->setText(QString("武器等级%1").arg(c[*nowc]->nature[12]));
        }
    }
    void dealback(){
        delete this;
    }
    void showcharacter();
    void dealswitchc(){
        *nowc=(*nowc+1)%3;
        showcharacter();
        update();
    }
    void sure();
    ~EquipWindow(){
        delete switchc;
        delete showc;
        delete nowc;
        delete back;
        delete upg;
        delete [] showcase;

    }
    void clickequip(int num){
        nowe=num;
        smallwindow* smwdw=new smallwindow(this);
        QLabel* background=smwdw->addlabel();
        background->setGeometry(160,140,300,200);
        background->setStyleSheet("background-color:white;");
        background->show();
      //  QLabel* pixmap=smwdw->addlabel();
        //pixmap->setPixmap(equipment[2+num]->pixmap);
        //pixmap->move(290,290);
        QFont font("宋体",15,QFont::Bold);
        QLabel* intro=smwdw->addlabel();
        intro->setText(QString("%1,仓库剩余数量: %2").arg(equipment[num+2]->name).arg(things[2+num]));
        intro->setFont(font);
        intro->setStyleSheet("color:black;");
        intro->setGeometry(170,150,280,100);
        intro->show();
        QPushButton* back2=smwdw->addbutton();
        back2->setGeometry(420,140,40,40);
        back2->setIcon(QPixmap("D:\\game\\Game4\\cancel.png"));
        back2->setIconSize(QSize(40,40));
        back2->show();
        QPushButton* wear=smwdw->addbutton();
        wear->setGeometry(200,280,100,50);
        wear->setText("装备");
        wear->setFont(font);
        wear->show();
        QPushButton* drop=smwdw->addbutton();
        drop->setGeometry(330,280,100,50);
        drop->setText("卸下");
        drop->setFont(font);
        drop->show();
        connect(back2,&QPushButton::clicked,smwdw,&smallwindow::destroythis);
        if(c[*nowc]->nature[num+8]){
            wear->setStyleSheet("color:gray;");
            connect(drop,&QPushButton::clicked,this,&EquipWindow::drop);
            connect(drop,&QPushButton::clicked,smwdw,&smallwindow::destroythis);
        }
        else{
            drop->setStyleSheet("color:gray;");
            if(things[2+num]){
                connect(wear,&QPushButton::clicked,this,&EquipWindow::wear);
                connect(wear,&QPushButton::clicked,smwdw,&smallwindow::destroythis);
            }
            else{
                wear->setStyleSheet("color:gray;");
            }

        }
    }
    void wear(){
        c[*nowc]->nature[nowe+8]++;
        things[2+nowe]--;
        showcharacter();
    }
    void drop(){
        c[*nowc]->nature[nowe+8]--;
        things[2+nowe]++;
        showcharacter();
    }
    void deal1(){
        clickequip(0);
    }
    void deal2(){
        clickequip(1);
    }
    void deal3(){
        clickequip(2);
    }
    void deal4(){
        clickequip(3);
    }

};

#endif // EQUIPWINDOW_H
