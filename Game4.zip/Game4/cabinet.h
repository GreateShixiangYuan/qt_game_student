
#ifndef CABINET_H
#define CABINET_H


#include <QMainWindow>
#include<QPushButton>
#include<QLabel>
class Cabinet:public QMainWindow
{
public:
    Cabinet(QWidget* parent=nullptr);
    QPushButton* things;
    QLabel* label;
};

#endif // CABINET_H
