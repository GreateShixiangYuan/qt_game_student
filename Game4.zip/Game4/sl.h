
#ifndef SL_H
#define SL_H

#include <QMainWindow>
#include<QPushButton>
#include <fstream>
#include<iostream>
#include"sharecode.h"
#include"home.h"
using namespace std;
class SL:public QMainWindow
{
    Q_OBJECT
public:
    SL(QWidget *parent = nullptr,Home* home_=nullptr);
    QPushButton cell[6];
    int now;
    Home* home;
    int state;//0表示读，1表示存
    QPushButton* reback;
    void storedata(){
        ofstream out_file("D:\\game\\Game4\\save.txt",std::ios::in | std::ios::out|ios::binary);
        out_file.seekp(now*22*sizeof(int), std::ios::beg);
        if(out_file){
            out_file.write((char*)(home->money),sizeof(int));
            for(int i=0;i<6;i++){
                out_file.write((char*)(home->things+i),sizeof(int));
            }
            for(int j=0;j<3;j++){
            for(int i=0;i<5;i++){
                out_file.write((char*)(home->c[j]->nature+8+i),sizeof(int));
            }
            }
            out_file.close();
        }
        cell[now].setText(QString("存档%1").arg(now+1));
        emit store();
    }
    void loaddata(){
        ifstream in_file("D:\\game\\Game4\\save.txt",ios::in|ios::binary);
        in_file.seekg(now*22*sizeof(int),std::ios::beg);
        if(in_file){
            in_file.read((char*)(home->money),sizeof(int));
            for(int i=0;i<6;i++){
            in_file.read((char*)(home->things+i),sizeof(int));
            }
            for(int j=0;j<3;j++){
            for(int i=0;i<5;i++){
                in_file.read((char*)(home->c[j]->nature+i+8),sizeof(int));
            }
            }
            in_file.close();
        }
        emit load();
    }
    ~SL(){

    }
    void createchoice(){
        smallwindow* smwdw=new smallwindow(this);
        QFont font("宋体",18,QFont::Bold);
        QLabel* back=smwdw->addlabel();
        back->setGeometry(200,280,400,100);
        back->setStyleSheet("background-color:white;");
        back->show();
        QPushButton* back2=smwdw->addbutton();
        back2->setGeometry(560,280,40,40);
        back2->setIcon(QPixmap("D:\\game\\Game4\\cancel.png"));
        back2->setIconSize(QSize(40,40));
        back2->show();
        QPushButton* use=smwdw->addbutton();
        use->setGeometry(350,300,100,50);
        use->setFont(font);
        use->show();
        connect(back2,&QPushButton::clicked,smwdw,&smallwindow::destroythis);
        if(state==0){
            use->setText("读取");
            if(!cell[now].text().isEmpty()){
                connect(use,&QPushButton::clicked,this,&SL::loaddata);
                connect(use,&QPushButton::clicked,smwdw,&smallwindow::destroythis);

            }
            else{
                use->setStyleSheet("color:gray;");
            }
        }
        else{
            use->setText("存档");
            connect(use,&QPushButton::clicked,this,&SL::storedata);
        }


    }
    void set1(){
        now=0;
        createchoice();
    }
    void set2(){
        now=1;
        createchoice();
    }
    void set3(){
        now=2;
        createchoice();
    }
    void set4(){
        now=3;
        createchoice();
    }
    void set5(){
        now=4;
        createchoice();
    }
    void set6(){
        now=5;
        createchoice();
    }
    void deletethis(){
        delete this;
    }
signals:
    void load();
    void store();

};

#endif // SL_H
