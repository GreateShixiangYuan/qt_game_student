
#include "weapon2.h"

Weapon2::Weapon2(QString filename,QGraphicsScene* scene_):QpixmapItem(filename,scene_)
{

    scene=scene_;
    scene->addItem(this);
    balls[0]=new Ball("D:\\game\\Game4\\ball_1.png",scene);
    balls[1]=new Ball("D:\\game\\Game4\\ball_1.png",scene);
    balls[2]=new Ball("D:\\game\\Game4\\ball_1.png",scene);
    scene->addItem(balls[0]);
    scene->addItem(balls[1]);
    scene->addItem(balls[2]);
    press=false;
    core=QPointF(600,600);
    balls[0]->setPos(600,500);
    balls[1]->setPos(600-50*1.7,650);
    balls[2]->setPos(600+50*1.7,650);
    rotation1=0;
    distance=200;
    attack1=1;
    attack2=40;
    attack3=400;
    attack4=10;
    xx2=0.2;
    naofweapon=new int[3];
    naofweapon[0]=20;
    naofweapon[1]=0;
    naofweapon[2]=0;
}
void Weapon2::setpos(QPointF temp){
    for(int i=0;i<3;i++){
        balls[i]->moveBy(temp.x(),temp.y());
    }
}
void Weapon2::shoot(QPointF direction_){
    Bullet2 *b2=new Bullet2("D:\\game\\Game4\\ball_2.png","D:\\game\\Game4\\explode.png",scene,direction_,core);
};
