
#include "diewindow.h"


DieWindow::DieWindow(QWidget* parent):QMainWindow(parent)
{
    resize(800,600);
    setWindowTitle("幸存者游戏");
    setWindowIcon(QIcon("D:\\game\\Game4\\icon.png"));
    QPalette palette;
    palette.setBrush(QPalette::Window,QBrush(QPixmap("D:\\game\\Game4\\die.png")));
    setPalette(palette);
    QFont font("宋体",25,QFont::Bold);
    QPixmap pixmap("D:\\game\\Game4\\buttonback3.png");

    regame=new QPushButton(this);
    regame->setGeometry(100,500,150,50);
    palette.setBrush(QPalette::Button, pixmap.scaled(150,50));
    regame->setAutoFillBackground(true);
    regame->setPalette(palette);
    regame->setFont(font);
    regame->setText("再次挑战");
    regame->setFlat(true);
    regame->setFocusPolicy(Qt::NoFocus);

    end=new QPushButton(this);
    end->setGeometry(550,500,150,50);
    end->setAutoFillBackground(true);
    end->setPalette(palette);
    end->setFont(font);
    end->setText("退出游戏");
    end->setFlat(true);
    end->setFocusPolicy(Qt::NoFocus);
}

