
#include "myview.h"

MyView::MyView(QWidget* parent):QGraphicsView(parent){
    home = new Home;
     //character=scene->character;
    setScene(home);
    // 设置视图中心对准场景中央物件
    int halfWidth = sceneRect().width() / 2;
    int halfHeight = sceneRect().height() / 2;

    // 视图滚动至场景中心
    centerOn(halfWidth, halfHeight);
    setFixedSize(802,602);
    setFocusPolicy(Qt::StrongFocus);
    setMouseTracking(true);
    setViewportUpdateMode(FullViewportUpdate); // 默认值即可

    connect(home->startgame,&QPushButton::clicked,this,&MyView::dealwithstartgame);
    connect(this,&MyView::clickcharacter,home,&Home::dealclickcharacter);
}
void MyView::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        // 将鼠标坐标转换为场景坐标
        QPointF pos = mapToScene(event->pos());

        // 获取与鼠标位置重合的图形项
        QGraphicsItem *item = home->itemAt(pos, transform());

        if (item != nullptr) {
            if(item==home->c[0]){
                *(home->clickc)=0;
                emit clickcharacter();
            }
            else if(item==home->c[1]){
                    *(home->clickc)=1;
                emit clickcharacter();
                }
            else if(item==home->c[2]){
                    *(home->clickc)=2;
                emit clickcharacter();
            }
        }
    }

    // 调用基类鼠标点击事件处理函数
    QGraphicsView::mousePressEvent(event);
}
