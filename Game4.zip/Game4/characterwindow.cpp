
#include "characterwindow.h"
const double scaleFactor = 0.5;

CharacterWindow::CharacterWindow(QWidget* parent,Scene* scene_):QMainWindow(parent)
{
    scene=scene_;
    s[0]="修罗刃\n有极高的伤害和强大的吸血之力\n每隔一段时间发出一道剑气，所向披靡";
    s[1]="魔法之力\n  三颗阴阳混沌球可抵挡攻击，对敌人造成伤害，并有嗜血之力\n  发射魔法球将所有敌人推开，魔法球爆炸可对敌人造成巨额伤害";
    s[2]="三生箭\n每次发射12支箭矢，不同箭可蕴含不同能量\n";
    resize(800,600);
    setWindowTitle("幸存者游戏");
    setWindowIcon(QIcon("D:\\game\\Game4\\icon.png"));
    QPalette palette;
    palette.setBrush(QPalette::Window,QBrush(QPixmap("D:\\game\\Game4\\weaponselect.jpg")));
    setPalette(palette);
    label1 = new QLabel("选择武器");
    layout()->addWidget(label1);
    QFont font("宋体",25,QFont::Bold);
    QFont font2("宋体",15);
    label1->setFont(font);
    label1->setGeometry(330, 20, 200, 30);
    label1->setStyleSheet("color: red;");
    frame=new QFrame(this);
    frame->setFrameStyle(QFrame::Box | QFrame::Plain);   // 显示一个黑色的简单框
    frame->setLineWidth(5);
    frame->setStyleSheet("background-color: gray; border-radius: 5px; box-shadow: 0px 0px 5px gray;");
    frame->setGeometry(200, 430, 400, 160);

    label2 = new QLabel(frame);
    label2->setText(s[1]);
    label2->setFont(font2);
    label2->setWordWrap(true);     // 自动换行
    label2->setAlignment(Qt::AlignTop | Qt::AlignLeft);  // 将文本上对齐，左对齐
    label2->setGeometry(10, 10, frame->width() - 20, frame->height() - 20);   // 留出边距
    pixmap[0]=new QPixmap("D:\\game\\Game4\\photo1.png");
    pixmap[1]=new QPixmap("D:\\game\\Game4\\photo2.png");
    pixmap[2]=new QPixmap("D:\\game\\Game4\\photo3.png");
    pix=new QPushButton(this);
    pos[0]=0;
    pos[1]=1;
    pos[2]=2;
    pix->setGeometry(240,60,320,240);
    pix->setIcon(*pixmap[pos[1]]);
    pix->setIconSize(pix->size());
    pixl=new QPushButton(this);
    pixl->setGeometry(40,120,160,120);
    pixl->setIcon(pixmap[0]->scaled(scaleFactor * pixmap[0]->size(), Qt::KeepAspectRatio));
    pixl->setIconSize(pixl->size());
    pixr=new QPushButton(this);
    pixr->setGeometry(600,120,160,120);
    pixr->setIcon(pixmap[2]->scaled(scaleFactor*pixmap[2]->size(),Qt::KeepAspectRatio));
    pixr->setIconSize(pixr->size());

    sure=new QPushButton(this);
    sure->setGeometry(350,340,100,50);
    palette.setBrush(QPalette::Button,QPixmap("D:\\game\\Game4\\buttonback2.png").scaled(100,50));
    sure->setAutoFillBackground(true);
    sure->setPalette(palette);
    sure->setText("确定");
    sure->setFont(font);
    sure->setStyleSheet("background-color:#CD853F ; color: black;");

    back=new QPushButton(this);
    back->setGeometry(20,530,100,50);
    palette.setBrush(QPalette::Button,QPixmap("D:\\game\\Game4\\buttonback2.png").scaled(100,50));
    back->setAutoFillBackground(true);
    back->setPalette(palette);
    back->setText("返回");
    back->setFont(font);
    back->setStyleSheet("color: black;");
    back->setFlat(true);
    back->setFocusPolicy(Qt::NoFocus);
    setlevel=nullptr;

    switchl = new QPushButton(this);
    switchl->setIcon(QPixmap("D:\\game\\Game4\\switchl.png"));
    switchl->setIconSize(QSize(100,80));
    switchl->setFixedSize(100, 80);
    switchl->move(100, 300);
    switchl->setFlat(true);
    switchl->setFocusPolicy(Qt::NoFocus);

    switchr = new QPushButton(this);
    switchr->setIcon(QPixmap("D:\\game\\Game4\\switchr.png"));
    switchr->setIconSize(QSize(100,80));
    switchr->setFixedSize(100, 80);
    switchr->move(600, 300);
    switchr->setFlat(true);
    switchr->setFocusPolicy(Qt::NoFocus);
    connect(switchl,&QPushButton::clicked,this,&CharacterWindow::changer);
    connect(pixl,&QPushButton::clicked,this,&CharacterWindow::changer);
    connect(pixr,&QPushButton::clicked,this,&CharacterWindow::changel);
    connect(switchr,&QPushButton::clicked,this,&CharacterWindow::changel);
    connect(sure,&QPushButton::clicked,this,&CharacterWindow::setcharacter);
    connect(back,&QPushButton::clicked,this,&CharacterWindow::destro);

}
void CharacterWindow::changel(){
    int temp=pos[0];
    pos[0]=pos[1];
    pos[1]=pos[2];
    pos[2]=temp;
    label2->setText(s[pos[1]]);
    pixl->setIcon(pixmap[pos[0]]->scaled(scaleFactor * pixmap[0]->size(), Qt::KeepAspectRatio));
    pix->setIcon(*pixmap[pos[1]]);
    pixr->setIcon(pixmap[pos[2]]->scaled(scaleFactor*pixmap[2]->size(),Qt::KeepAspectRatio));
}
void CharacterWindow::changer(){
    int temp=pos[2];
    pos[2]=pos[1];
    pos[1]=pos[0];
    pos[0]=temp;
    label2->setText(s[pos[1]]);
    pixl->setIcon(pixmap[pos[0]]->scaled(scaleFactor * pixmap[0]->size(), Qt::KeepAspectRatio));
    pix->setIcon(*pixmap[pos[1]]);
    pixr->setIcon(pixmap[pos[2]]->scaled(scaleFactor*pixmap[2]->size(),Qt::KeepAspectRatio));
}
