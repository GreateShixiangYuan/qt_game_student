
#include "weapon3.h"

Weapon3::Weapon3(QString filename,QGraphicsScene* scene_):QpixmapItem(filename,scene_)
{

    setPixmap(pixmap);
    scene=scene_;
    scene->addItem(this);
    times=0;
    predirection=QPointF(1,0);
    press=false;
    setPos(630,600);
    direction=QPointF(1,0);
    rotation1=0;
    distance=250;
    attack1=100;
    attack2=150;
    attack3=100;
    xx3=0.15;
    naofweapon=new int[3];
    naofweapon[0]=30;
    naofweapon[1]=0;
    naofweapon[2]=3;
}
