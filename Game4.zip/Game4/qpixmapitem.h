
#ifndef QPIXMAPTTEM_H
#define QPIXMAPTTEM_H
#include<QGraphicsPixmapItem>
#include<QString>
#include<QObject>

#include<QGraphicsScene>
#include<QPixmap>
#include<QBitmap>
#include<QImage>
enum ObjectTypeEnum {
    ObjectType = QGraphicsItem::UserType + 1,
    EnemyType,
    BulletType,
    MonsterType,
    CharacterType,
    ObstacleType,
    WeaponType,
    BorderType,
    Weapon2Type,
    Weapon3Type,
    Weapon4Type,
    Cry1,
    Cry2

};
class Ball:public QGraphicsPixmapItem{
public:
    Ball(QString f1,QGraphicsScene* scene):QGraphicsPixmapItem(nullptr){
        pixmap.load(f1);
        setPixmap(pixmap);
        setShapeMode(QGraphicsPixmapItem::MaskShape);
        setData(ObjectType, Weapon2Type);
        scene->addItem(this);
        count=0;
        setTransformOriginPoint(pixmap.width()/2,pixmap.height()/2);
    }
    int count;
    QPixmap pixmap;
    void advance(int){
        if(count++%4==0){
            setRotation(rotation()+30);
        }
    }
};
class Bullet2:public QGraphicsPixmapItem
{
public:
    Bullet2(QString f1,QString f2,QGraphicsScene* scene,QPointF direction_,QPointF position):QGraphicsPixmapItem(nullptr){
        pixmap.load(f1);
        pixexp.load(f2);
        scene->addItem(this);
        QPointF core=pos()+QPointF(pixmap.width()/2,pixmap.height()/2);
        setPos(position+direction_*60-core);
        direction=direction_;
        setPixmap(pixmap);
        setShapeMode(QGraphicsPixmapItem::MaskShape);
        setData(ObjectType, Weapon4Type);
        speed=6;
        crash=0;

        time=30;
    }
    QPixmap pixmap;
    QPixmap pixexp;
    qreal speed;
    int crash;
    int time;
    QPointF direction;
    void advance(int){
        time--;
        if(crash){
            if(crash==1){
                 setPixmap(pixexp);
                setData(ObjectType, Weapon3Type);
                setPos(pos()-QPointF((pixexp.width()-pixmap.width())/2,(pixexp.height()-pixmap.height())/2));
            }
            if(crash++==15){
                scene()->removeItem(this);
                delete this;
            }
            return;
        }
        if(time==0){
            crash=1;
            return;
        }
        QList<QGraphicsItem*> items = collidingItems();
        if(items.count()){
            foreach (auto *item, items) {
                if (item->data(ObjectType) == ObstacleType||item->data(ObjectType) == BorderType){
                    crash=1;
                    return;
                }
            }
        }
        setPos(pos()+speed*direction);
    }

};
class Bullet3:public QGraphicsPixmapItem
{
public:
    Bullet3(QString f1,QString f2,QGraphicsScene* scene,qreal angle,QPointF position):QGraphicsPixmapItem(nullptr),direction(cos(angle*3.14/180),-sin(3.14*angle/180)){
        pixmap.load(f1);
        pixexp.load(f2);
        setTransformOriginPoint(pixmap.width()/2,pixmap.height()/2);
        scene->addItem(this);
        setPixmap(pixmap);
        setRotation(-angle);
        setPos(position);
        moveBy(direction.x()*40,direction.y()*40);
        setShapeMode(QGraphicsPixmapItem::MaskShape);
        speed=12;
        crash=0;

    }
    QPixmap pixmap;
    QPixmap pixexp;
    qreal speed;
    int crash;
    QPointF direction;
    void advance(int){
        if(crash){
            if(crash==1){
                QPointF temp=pos();
                setPixmap(pixexp);
                QPointF cor=mapToScene(boundingRect().center());
                moveBy(temp.x()-cor.x(),temp.y()-cor.y());
                setData(ObjectType, Weapon3Type);

            }
            if(crash++==5){
                scene()->removeItem(this);
                delete this;
            }
            return;
        }
        QList<QGraphicsItem*> items = collidingItems();
        if(items.count()){
            foreach (auto *item, items) {
                if (item->data(ObjectType) == ObstacleType||item->data(ObjectType) == BorderType||item->data(ObjectType) == EnemyType){
                    crash=1;
                    return;
                }
            }
        }
        setPos(pos()+speed*direction);
    }

};

class QpixmapItem:public QGraphicsPixmapItem
{
public:
    QpixmapItem(QString f1,QGraphicsScene* scene_):QGraphicsPixmapItem(nullptr){
        pixmap.load(f1);
        pixmap_reverse=pixmap.transformed(QTransform().scale(-1,1));
        type=true;
        press=false;
        setPixmap(pixmap);
        setShapeMode(QGraphicsPixmapItem::MaskShape);
        scene=scene_;
        rect=pixmap.rect();
        scene->addItem(this);
        height=rect.height();
        width=rect.width();
        times=0;
        radius=100;
        xx1=0;
        xx2=0;
        xx3=0;
        xx4=0;
        attack1=0;
        attack2=0;
        attack3=0;
        attack4=0;
        qi=nullptr;
        explode=nullptr;
    }
    int times;
    QPointF predirection;
    QpixmapItem* qi;
    bool ifqi;
    //sword

    qreal rotation1;
    qreal distance;
    Ball* balls[3];
    QpixmapItem* explode;
    bool ifexp;
    void setpos(QPointF);
    qreal radius;
    //magic
    int* naofweapon;
    QPointF direction;
    QPointF core;
    bool press;
    QRectF rect;
    QRectF rectc;
    QGraphicsScene* scene;
    void changepix();
    QPixmap pixmap;
    QPixmap pixmap_reverse;
    bool type;
    qreal height;
    qreal width;
    int attack1;
    int attack2;
    int attack3;
    int attack4;
    qreal xx1=0;
    qreal xx2=0;
    qreal xx3=0;
    qreal xx4=0;
    bool movable();
    void die(){
        scene->removeItem(this);
        delete this;
    }
    virtual void up1(){}
    virtual void up2(){}
    virtual void up3(){}
    virtual void setweaponnature(int){}
    void ifreverse();
    void virtual shoot(QPointF){};
    ~QpixmapItem(){

    }





};
class Crystal1:public QGraphicsPixmapItem{
public:
    QGraphicsScene* scene;
    Crystal1(QGraphicsScene* scene_,QPointF position):QGraphicsPixmapItem(nullptr){
        scene=scene_;
        setPixmap(QPixmap("D:\\game\\Game4\\crystal1.png"));
        setShapeMode(QGraphicsPixmapItem::MaskShape);
        scene->addItem(this);
        setData(ObjectType, Cry1);
        setPos(position);
    }
    void advance(int phase){
        QList<QGraphicsItem*> items = collidingItems();
        if(items.count()){
            foreach (auto *item, items) {
                if (item->data(ObjectType) == CharacterType){
                    scene->removeItem(this);
                    delete this;
                    return;
                }
            }
        }

    }
};
class Crystal2:public QGraphicsPixmapItem{
public:
    QGraphicsScene* scene;
    Crystal2(QGraphicsScene* scene_,QPointF position):QGraphicsPixmapItem(nullptr){
        scene=scene_;
        setPixmap(QPixmap("D:\\game\\Game4\\crystal2.png"));
        setShapeMode(QGraphicsPixmapItem::MaskShape);
        setData(ObjectType, Cry2);
        scene->addItem(this);
        setPos(position);
    }
     void advance(int phase){
        QList<QGraphicsItem*> items = collidingItems();
        if(items.count()){
            foreach (auto *item, items) {
                if (item->data(ObjectType) == CharacterType){
                    scene->removeItem(this);
                    delete this;
                    return;
                }
            }
        }

    }
};

#endif // QPIXMAPTTEM_H
