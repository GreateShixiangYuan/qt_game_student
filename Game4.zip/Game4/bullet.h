
#ifndef BULLET_H
#define BULLET_H
#include "qpixmapitem.h"

class Bullet:public QpixmapItem
{
public:
    int crash;
    int speed;
    Bullet(QString,QPointF,QGraphicsScene*);
    QPointF direction;
    void advance(int phase);
};

#endif // BULLET_H
