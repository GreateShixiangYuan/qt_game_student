
#ifndef CHARACTER_H
#define CHARACTER_H
#include"qpixmapitem.h"
#include<QKeyEvent>
#include<QGraphicsScene>
#include<QDebug>
#include<QObject>
#include<QPainter>
#include <QtCore/qmath.h>
class Character:public QpixmapItem
{
public:
    bool W;
    bool S;
    bool A;
    bool D;
    QPointF direction;
    //           0:hp1:def 2:atk3:atksp4:pet 5:skr 6:ske 7:spd//8:hand,9:shoes
    //10 head,11 body,
    qreal hp;
    qreal nowhp;
    qreal speed;
    qreal attackspeed;
    qreal atk;
    qreal atkspeed;
    qreal defense;
    qreal penetration;
    qreal strikerate;
    qreal strikeeffect;
    int dengji;
    int changes;
    int meminfo;
    qreal experience;
    qreal explimit;
    QPixmap pixmap_[3];
    QPixmap pixmap_r[3];
    QString updiscribe[10];
    QGraphicsScene* scene;
    QpixmapItem* weapon;
    Character(QString filename,QGraphicsScene*);
    void advance(int phase);
    void makeit1();
    void move(qreal speed){
        moveBy(direction.x()*speed,direction.y()*speed);
    }
    void moveback(qreal speed){
        moveBy(-direction.x()*speed,-direction.y()*speed);
    }
    void setpix(QString f){
        pixmap.load(f);
        pixmap_reverse=pixmap.transformed(QTransform().scale(-1,1));
        setPixmap(pixmap);
        rect=pixmap.rect();
        height=rect.height();
        width=rect.width();
    }
    int movefortime(QPointF dire,int times);
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    void upgrade();
    void up1();//越前概率越大//add hp
    void up2();//add atk
    void up3();//增加防御
    void up4();//增加防御穿透
    void up5();//add 暴击率
    void up6();//add 暴击效果
    void up7();//add speed
    void useup();
};

#endif // CHARACTER_H
