
#include "store.h"

Store::Store(QWidget* parent,int* equipment,int* money_,Equipment** equipment_):MyWidget(parent)
{


    timer=new QTimer(this);
    things=equipment;
    money=money_;
    equip=equipment_;
    QPalette palette;
    palette.setBrush(QPalette::Window,QBrush(QPixmap("D:\\game\\Game4\\store.png")));
    setPalette(palette);
    resize(800,600);
    QPixmap coin("D:\\game\\Game4\\coin.png");
    QLabel* coi=new QLabel(this);
    coi->setPixmap(coin);
    coi->move(400,70);
    showmoney=new QLabel(this);
    showmoney->setText(QString("%1").arg(*money));
    showmoney->move(440,70);
    showmoney->setStyleSheet("background-color: transparent;font-size: 25px;color:rgb(255,215,0);");
    showmoney->show();
    cancel=new QPushButton(this);
    cancel->setGeometry(745,30,50, 50); // 设置按钮大小
    cancel->setFlat(true);
    cancel->setFocusPolicy(Qt::NoFocus);
    connect(this->cancel,&QPushButton::clicked,this,&Store::hide);

    QFont font("宋体",25,QFont::Bold);
    for(int i=0;i<6;i++){
        int c=0;
        if(i>2){
            c=1;
        }
        int r=i%3;
        c*=230;
        r*=260;
    equipment_[i]->setParent(this);
    equipment_[i]->setGeometry(95+r,150+c,80,80);

    label[i]=new QLabel(this);
    label[i]->setGeometry(75+r,245+c,120,30);//
    label[i]->setStyleSheet("font-size: 20px;color:red;");
    label[i]->setAlignment(Qt::AlignHCenter | Qt::AlignTop);
    label[i]->setText(equipment_[i]->name);

    buy[i]=new QPushButton(this);
    buy[i]->setGeometry(75+r,280+c,120,50);
    buy[i]->setIcon(coin);
    buy[i]->setIconSize(coin.size());
    buy[i]->setFont(font);
    buy[i]->setStyleSheet("color:yellow;");
    buy[i]->setText(QString("%1").arg(QString("%1").arg(equipment_[i]->price)));
    buy[i]->setFlat(true);
    buy[i]->setFocusPolicy(Qt::NoFocus);


    }
    QFont font2("宋体",20,QFont::Bold);
    buysuc=new QLabel("\n恭喜你，购买成功！");
    buysuc->setAlignment(Qt::AlignHCenter);
    buysuc->setParent(this);
    buysuc->setFont(font2);
    buysuc->setGeometry(200,250,400,100);
    buysuc->setStyleSheet("background-color:yellow;color:red;");
    buysuc->hide();
    buyfai=new QLabel("\n很遗憾，您的余额不足");
    buyfai->setParent(this);
    buyfai->setFont(font2);
    buyfai->setGeometry(200,2500,400,100);
    buyfai->setStyleSheet("background-color:yellow;color:red;");
    buyfai->hide();

    connect(buy[0],&QPushButton::clicked,this,&Store::deal1);
    connect(buy[1],&QPushButton::clicked,this,&Store::deal2);
    connect(buy[2],&QPushButton::clicked,this,&Store::deal3);
    connect(buy[3],&QPushButton::clicked,this,&Store::deal4);
    connect(buy[4],&QPushButton::clicked,this,&Store::deal5);
    connect(buy[5],&QPushButton::clicked,this,&Store::deal6);
    connect(this,&Store::clickbuy,this,&Store::starttimer);

    connect(timer,&QTimer::timeout,buysuc,&QLabel::hide);
    connect(timer,&QTimer::timeout,buyfai,&QLabel::hide);
    connect(timer,&QTimer::timeout,this,&Store::resetshowmoney);


}

