
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QIcon>
#include<QPushButton>
#include"myview.h"
#include"store.h"
#include"scene.h"
#include"sl.h"
class MainWindow : public QMainWindow

{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    void endgame(){
        if(sl==nullptr){
            sl=new SL(nullptr,view->home);
        }
        sl->state=1;
        sl->show();
        connect(sl,&SL::store,sl,&SL::deletethis);
        hide();
    }
    void closeEvent(QCloseEvent* event);
    void loaddata();
    QPushButton* start;
    QPushButton* load;
    QPushButton* set;
    MyView* view;
    SL* sl;
    ~MainWindow(){
        delete start;
        delete load;
        if(view){
            delete view;
        }
    }
public slots:
    void startclick();


};


#endif // MAINWINDOW_H
