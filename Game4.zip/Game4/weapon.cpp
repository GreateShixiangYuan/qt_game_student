
#include "weapon.h"

Weapon::Weapon(QString filename,QGraphicsScene* scene_):QpixmapItem(filename,scene_)
{
    pixmap_reverse=pixmap.transformed(QTransform().scale(1,-1));
    setData(ObjectType, WeaponType);
    scene=scene_;
    scene->addItem(this);
    times=0;
    predirection=QPointF(0,0);
    press=false;
    direction=QPointF(1,0);
    setTransformOriginPoint(0,rect.height()/2);
    ifqi=false;
    attack1=4000;
    attack2=2000;
    xx1=0.25;
    xx2=0.25;
    naofweapon=new int[3];
    naofweapon[0]=0;
    naofweapon[1]=0;
    naofweapon[2]=0;
}
