
#include "equipwindow.h"

EquipWindow::EquipWindow(QWidget*parent,Jues** c_,Equipment** e,int num,int* thing_,int* mon):MyWidget(parent)
{
    money=mon;
    c=c_;
    things=thing_;
    equipment=e;
    equipback=new QPixmap("D:\\game\\Game4\\equipback.jpg");
    showc=new QLabel(this);
    nowc=new int(num);
    showc->setGeometry(200,150,200,200);
    QFont font("宋体",13,QFont::Bold);
    QPalette palette;
    palette.setBrush(QPalette::Window,QBrush(QPixmap("D:\\game\\Game4\\weaponselect.jpg")));
    setPalette(palette);
    palette.setBrush(QPalette::Button,QBrush(*equipback));
    showcase=new QPushButton[4];
    for(int i=0;i<4;i++){
        showcase[i].setParent(this);
        showcase[i].setGeometry(60,30+100*i,80,80);
        showcase[i].setPalette(palette);
        showcase[i].setAutoFillBackground(true);
        showcase[i].setText(equipment[2+i]->name);
        showcase[i].setFont(font);
        showcase[i].setStyleSheet("color:gray;");
        showcase[i].setIconSize(QSize(80,80));
        showcase[i].setFlat(true);
       // showcase[i].setFocusPolicy(Qt::NoFocus);

    }
    showcharacter();

    back=new QPushButton(this);
    back->setGeometry(560,0,40,40);
    back->setIcon(QPixmap("D:\\game\\Game4\\cancel.png"));
    back->setIconSize(QSize(40,40));
    switchc=new QPushButton(this);
    switchc->setGeometry(550,360,50,70);
    switchc->setIcon(QPixmap("D:\\game\\Game4\\switchr.png"));
    switchc->setIconSize(QSize(100,80));

    upg=new QPushButton(this);
    upg->setGeometry(470,250,100,40);
    palette.setBrush(QPalette::Button,QBrush(QPixmap("D:\\game\\Game4\\buttonback2.png").scaled(100,40)));
    upg->setPalette(palette);
    upg->setText("升级武器");
    upg->setAutoFillBackground(true);
    upg->setFlat(true);
    upg->setFocusPolicy(Qt::NoFocus);
    upg->setFont(font);

    showdj=new QLabel(this);
    showdj->setFont(font);
    showdj->setStyleSheet("color:yellow;");
    showdj->setText(QString("武器等级%1").arg(c[*nowc]->nature[12]));
    showdj->move(450,150);

    if(*money<500){
        showdj->setStyleSheet("color:gray;");
    }
    else{
        connect(upg,&QPushButton::clicked,this,&EquipWindow::upgrade);
    }
    connect(back,&QPushButton::clicked,this,&EquipWindow::dealback);
    connect(switchc,&QPushButton::clicked,this,&EquipWindow::dealswitchc);
    connect(showcase+0,&QPushButton::clicked,this,&EquipWindow::deal1);
    connect(showcase+1,&QPushButton::clicked,this,&EquipWindow::deal2);
    connect(showcase+2,&QPushButton::clicked,this,&EquipWindow::deal3);
    connect(showcase+3,&QPushButton::clicked,this,&EquipWindow::deal4);
}

void EquipWindow::showcharacter(){
    for(int i=0;i<4;i++){
        showcase[i].setText("");
        showcase[i].setIcon(QIcon());
        if(c[*nowc]->nature[8+i]){

            showcase[i].setIcon(equipment[2+i]->pixmap);

        }
        else{
            showcase[i].setText(equipment[2+i]->name);
        }
    }
    showc->setPixmap(c[*nowc]->pixmap.scaled(showc->size()));
}
