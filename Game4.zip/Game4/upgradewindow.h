
#ifndef UPGRADEWINDOW_H
#define UPGRADEWINDOW_H




class UpgradeWindow
{
public:
    UpgradeWindow();
};

#endif // UPGRADEWINDOW_H
