
#include "cabinet.h"

Cabinet::Cabinet(QWidget* parent):QMainWindow(parent)
{

    things=new QPushButton(this);



}

