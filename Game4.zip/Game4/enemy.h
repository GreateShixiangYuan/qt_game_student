
#ifndef ENEMY_H
#define ENEMY_H
#include "qpixmapitem.h"
#include<QRandomGenerator>
#include "bullet.h"
#include<QPointF>
#include<QPainter>
class Enemy:public QpixmapItem,public QObject
{
public:
    bool targeted;
    QPointF destination;
    qreal hp;
    qreal nowhp;
    qreal speed;
    qreal atk;
    qreal defense;
    QPointF direction;
    bool ifcontrol;
    qreal gapx;
    qreal gapy;
    Enemy(QString,QGraphicsScene* scene);
    void advance(int phase);
    void resetdirection();
    void shoot();
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
};
class Enemy2:public QpixmapItem,public QObject
{
public:
    bool targeted;
    QPointF destination;
    qreal hp;
    qreal nowhp;
    qreal speed;
    qreal atk;
    qreal defense;
    QPointF direction;
    bool ifcontrol;
    qreal gapx;
    qreal gapy;
    Enemy2(QGraphicsScene* scene);
    void advance(int phase);
    void resetdirection();
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
};

#endif // ENEMY_H
