
#ifndef MYVIEW_H
#define MYVIEW_H
#include"scene.h"
#include"home.h"
#include<QGraphicsView>
#include<QGraphicsItem>
#include<QRectF>
#include<QChar>
#include<QLabel>
#include<QString>
#include<QGraphicsProxyWidget>
#include"characterwindow.h"

class MyView : public QGraphicsView {
    Q_OBJECT
public:
    MyView(QWidget* parent=nullptr);
    ~MyView(){}

    Scene* scene;   
    Home* home;//两个场景
    int mem[3];
    Character* character;//用于获得角色移动信息
    int resttime;//计时
    QLabel* timelabel;
    CharacterWindow* characterwindow;
    smallwindow* victorywdw;
    QPushButton* stop;
    void move(){
        centerOn(character->pos()+QPointF(character->width/2,character->height/2));
    }
    void startscenetimer(){
        scene->timer->start(40);
        setFocusPolicy(Qt::StrongFocus);
    }
    void gothrough1s(){
        resttime--;
        if(resttime<=0){
            return;
        }
        if(resttime<=30){
            timelabel->setStyleSheet("font-size: 20px;color:pink;");
        }
        QString formattedTime = QString("剩余时间 : %1 : %2").arg(resttime/60,2,10,QChar('0')).arg(resttime%60,2,10,QChar('0'));
        timelabel->setText(formattedTime);


    }
    void dealwithstartgame(){
        scene=new Scene;
        character=scene->character;
        connect(scene,&Scene::startgame,this,&MyView::entergame);
        characterwindow=new CharacterWindow(this,scene);
        connect(characterwindow->sure,&QPushButton::clicked,this,&MyView::setcharacternature);
        characterwindow->show();
    }
    void setcharacternature(){
        int num=characterwindow->pos[1];
        character->hp=home->c[num]->nature[0];
        character->defense=home->c[num]->nature[1];
        character->atk=home->c[num]->nature[2];
        character->atkspeed=home->c[num]->nature[3];
        character->penetration=home->c[num]->nature[4];
        character->strikerate=home->c[num]->nature[5];
        character->strikeeffect=home->c[num]->nature[6];
        character->speed=home->c[num]->nature[7];
        //0:hp 1:def 2:atk 3:atksp 4:pet 5:skr 6:ske 7:spd//8:hand,9:shoes
        //10 head,11 body,
        for(int i=0;i<4;i++){
            if(home->c[num]->nature[i+8]){
                scene->character->hp+=home->equipment[2+i]->nature[0];
                scene->character->defense+=home->equipment[2+i]->nature[1];
                scene->character->atk+=home->equipment[2+i]->nature[2];
                scene->character->atkspeed+=home->equipment[2+i]->nature[3];
                scene->character->penetration+=home->equipment[2+i]->nature[4];
                scene->character->strikerate+=home->equipment[2+i]->nature[5];
                scene->character->strikeeffect+=home->equipment[2+i]->nature[6];
                scene->character->speed+=home->equipment[2+i]->nature[7];
            }
        }
        character->nowhp=character->hp;
        character->weapon->setweaponnature(home->c[num]->nature[12]);

    }
    void entergame(){
        delete characterwindow;
        home->timer->stop();
        setScene(scene);
        int halfWidth = sceneRect().width() / 2;
        int halfHeight = sceneRect().height() / 2;
        // 视图滚动至场景中心
        centerOn(halfWidth, halfHeight);
        setFocusPolicy(Qt::StrongFocus);
        setMouseTracking(true);
        setViewportUpdateMode(FullViewportUpdate);
        character=scene->character;
        //初始化时钟
        switch (scene->difficulty) {
        case 0:
            resttime=60;
           break;
        case 1:
           resttime=120;
           break;
        case 2:
           resttime=180;
           break;
        default:
           resttime=0;
            break;
        }
        scene->timelimit=resttime;
        timelabel=new QLabel(this);
        QString formattedTime = QString("剩余时间 : %1 : %2").arg(resttime/60,2,10,QChar('0')).arg(resttime%60,2,10,QChar('0'));
        timelabel->setText(formattedTime);
        timelabel->setStyleSheet("font-size: 20px;color:red;"); // 设置字体大小
        timelabel->setAlignment(Qt::AlignHCenter | Qt::AlignTop);
        timelabel->move(400-timelabel->width()/2,5);
        timelabel->show();

        stop=new QPushButton(this);
        stop->setGeometry(750,10,40,40);
        stop->setIcon(QPixmap("D:\\game\\Game4\\continue.png"));
        stop->setIconSize(QSize(40,40));
        stop->show();
        connect(scene,&Scene::gothrough1s,this,&MyView::gothrough1s);
        connect(scene,&Scene::realmove,this,&MyView::move);
        connect(stop,&QPushButton::clicked,this,&MyView::dealwithclicktostop);
        connect(scene,&Scene::die,this,&MyView::dealdie);
        connect(scene,&Scene::victory,this,&MyView::dealvictory);
        connect(scene,&Scene::upgrade,this,&MyView::dealupgrade);
        scene->timer->start(40);
    }
    void mousePressEvent(QMouseEvent *event) override;
    void dealwithclicktostop(){
        scene->timer->stop();
        stop->setIcon(QPixmap("D:\\game\\Game4\\continue.png"));
        smallwindow* smwdw=new smallwindow(this);
        QLabel* back=smwdw->addlabel();
        back->setGeometry(80,60,640,480);
        back->setPixmap(QPixmap("D:\\game\\Game4\\stopwindow.png"));
        back->show();
        QPalette palette;
        QFont font("宋体",18,QFont::Bold);
        palette.setBrush(QPalette::Button,QPixmap("D:\\game\\Game4\\buttonback3.png").scaled(200,70));
        QPushButton* rt=smwdw->addbutton();
        rt->setGeometry(300,400,200,70);
        rt->setAutoFillBackground(true);
        rt->setPalette(palette);
        rt->setFont(font);
        rt->setStyleSheet("color: yellow;");
        rt->setFlat(true);
        rt->setFocusPolicy(Qt::NoFocus);
        rt->setText("继续");
        rt->show();
        QPushButton* usemdc=smwdw->addbutton();
        usemdc->setGeometry(80,400,200,70);
        usemdc->setAutoFillBackground(true);
        usemdc->setPalette(palette);
        usemdc->setFont(font);
        usemdc->setStyleSheet("color: yellow;");
        usemdc->setFlat(true);
        usemdc->setFocusPolicy(Qt::NoFocus);
        usemdc->setText("使用药物");
        usemdc->show();
        QPushButton* end=smwdw->addbutton();
        end->setGeometry(520,400,200,70);
        end->setAutoFillBackground(true);
        end->setPalette(palette);
        end->setFont(font);
        end->setStyleSheet("color: yellow;");
        end->setFlat(true);
        end->setFocusPolicy(Qt::NoFocus);
        end->setText("结束本局");
        end->show();
        connect(rt,&QPushButton::clicked,this,&MyView::startscenetimer);
        connect(rt,&QPushButton::clicked,smwdw,&smallwindow::destroythis);
        connect(end,&QPushButton::clicked,this,&MyView::windupaccount);
        connect(end,&QPushButton::clicked,smwdw,&smallwindow::destroythis);
        connect(usemdc,&QPushButton::clicked,this,&MyView::showmedicine);

    }
    void windupaccount(){
        int income=0;
        switch (scene->difficulty) {
        case 0:
            income=60-resttime;
            break;
        case 1:
            income=(120-resttime)*1.4;
            break;
        case 2:
            income=(180-resttime)*1.8;
            break;
        default:
            break;
        }
        *(home->money)+=income;
        endgame();

    }
    void endgame(){
        setScene(home);
        if(scene!=nullptr)
        delete scene;
            if(stop!=nullptr)
        delete stop;
        if(timelabel!=nullptr)
        delete timelabel;

        home->timer->start(50);
    }
    void showmedicine(){
        smallwindow* smwdw=new smallwindow(this);
        QFont font("宋体",18,QFont::Bold);
        QLabel* intro=smwdw->addlabel();
        intro->setText(QString("%1,仓库剩余数量: %2").arg(home->equipment[0]->name).arg(home->things[0]));
        intro->setFont(font);
        intro->setStyleSheet("color:black;background-color:white;");
        intro->setGeometry(200,150,400,200);
        intro->show();
        QPushButton* back2=smwdw->addbutton();
        back2->setGeometry(560,150,40,40);
        back2->setIcon(QPixmap("D:\\game\\Game4\\cancel.png"));
        back2->setIconSize(QSize(40,40));
        back2->show();
        QPushButton* use=smwdw->addbutton();
        use->setGeometry(350,300,100,50);
        use->setText("使用");
        use->setFont(font);
        use->show();
        connect(back2,&QPushButton::clicked,smwdw,&smallwindow::destroythis);
        if(home->things[0]){
        connect(use,&QPushButton::clicked,this,&MyView::usemedicine);
        connect(use,&QPushButton::clicked,this,&MyView::showmedicine);
        connect(use,&QPushButton::clicked,smwdw,&smallwindow::destroythis);

        }
        else{
        use->setStyleSheet("color:gray;");
        }
    }
    void usemedicine(){
        home->things[0]--;
        scene->character->nowhp+=3000;
        if(scene->character->nowhp>scene->character->hp){
            scene->character->nowhp=scene->character->hp;
        }
        scene->character->changes++;
    }
    void userelive(){
        home->things[1]--;
        scene->character->nowhp=scene->character->hp;
        scene->character->changes++;
        scene->timer->start(40);
    }
    void dealdie(){
        scene->timer->stop();
        smallwindow* smwdw=new smallwindow(this);
        QLabel* background=smwdw->addlabel();
        background->setPixmap(QPixmap("D:\\game\\Game4\\die.png"));
        background->show();
        QPalette palette;
        palette.setBrush(QPalette::Window,QBrush(QPixmap()));
        setPalette(palette);
        QFont font("宋体",25,QFont::Bold);
        QPixmap pixmap("D:\\game\\Game4\\buttonback3.png");

        QPushButton* regame=smwdw->addbutton();
        regame->setGeometry(100,500,150,50);
        palette.setBrush(QPalette::Button, pixmap.scaled(150,50));
        regame->setAutoFillBackground(true);
        regame->setPalette(palette);
        regame->setFont(font);
        regame->setText("复活");
        regame->setFlat(true);
        regame->setFocusPolicy(Qt::NoFocus);

        regame->show();

        QPushButton* end=smwdw->addbutton();
        end->setGeometry(550,500,150,50);
        end->setAutoFillBackground(true);
        end->setPalette(palette);
        end->setFont(font);
        end->setText("回家");
        end->setFlat(true);
        end->setFocusPolicy(Qt::NoFocus);
        end->show();

        connect(end,&QPushButton::clicked,this,&MyView::windupaccount);
        connect(end,&QPushButton::clicked,smwdw,&smallwindow::destroythis);
        if(home->things[1]>0){
            connect(regame,&QPushButton::clicked,this,&MyView::userelive);
            connect(regame,&QPushButton::clicked,smwdw,&smallwindow::destroythis);

        }
        else{
            regame->setStyleSheet("color:gray;");
        }
    }
    void dealvictory(){
        scene->timer->stop();
        smallwindow* smwdw=new smallwindow(this);
        QLabel* background=smwdw->addlabel();
        background->setPixmap(QPixmap("D:\\game\\Game4\\victory.png"));
        background->show();
        QFont font("宋体",25,QFont::Bold);
        QPalette palette;
        palette.setBrush(QPalette::Button,QBrush(QPixmap("D:\\game\\Game4\\buttonback2.png").scaled(200,50)));


        QPushButton* end=smwdw->addbutton();
        end->setGeometry(300,500,200,50);
        end->setAutoFillBackground(true);
        end->setPalette(palette);
        end->setFont(font);
        end->setText("回家");
        end->setFlat(true);
        end->setFocusPolicy(Qt::NoFocus);
        end->show();
        int income=0;
        switch (scene->difficulty) {
        case 0:
            income=100;
            break;
        case 1:
            income=300;
            break;
        case 2:
            income=500;
            break;
        default:
            break;
        }
        *(home->money)+=income;
        QLabel* showmon=smwdw->addlabel();
        showmon->setText(QString("收获金币: %1枚").arg(income));
        showmon->move(300,350);
        showmon->setFont(font);
        showmon->setStyleSheet("color:yellow;");
        showmon->show();
        connect(end,&QPushButton::clicked,this,&MyView::endgame);
        connect(end,&QPushButton::clicked,smwdw,&smallwindow::destroythis);

    }
    void dealupgrade(){

        scene->timer->stop();
        QRandomGenerator generator= QRandomGenerator::securelySeeded();
        int order;

        smallwindow* smwdw=new smallwindow(this);
        QLabel* background=smwdw->addlabel();
        background->setPixmap(QPixmap("D:\\game\\Game4\\weaponselect.jpg").scaled(640,480));
        background->show();
        background->move(80,60);
        QFont font("宋体",20,QFont::Bold);

        order=generator.bounded(10);
        mem[0]=order;
        QPushButton* nature1=smwdw->addbutton();
        nature1->setGeometry(90,80,200,300);
        nature1->setText(character->updiscribe[order]);
        nature1->setFont(font);
        nature1->setFocusPolicy(Qt::NoFocus);
        nature1->setStyleSheet("background-color:white;");
        nature1->show();
        connect(nature1,&QPushButton::clicked,this,&MyView::withoutname1);
        connect(nature1,&QPushButton::clicked,this,&MyView::startscenetimer);
        connect(nature1,&QPushButton::clicked,smwdw,&smallwindow::destroythis);
        while (order==mem[0]) {
            order=generator.bounded(10);
        }
        mem[1]=order;
        QPushButton* nature2=smwdw->addbutton();
        nature2->setGeometry(300,80,200,300);
        nature2->setText(scene->character->updiscribe[order]);
        nature2->setFont(font);
        nature2->setStyleSheet("background-color:white;");
        nature2->setFocusPolicy(Qt::NoFocus);
        nature2->show();
        connect(nature2,&QPushButton::clicked,this,&MyView::withoutname2);
        connect(nature2,&QPushButton::clicked,this,&MyView::startscenetimer);
        connect(nature2,&QPushButton::clicked,smwdw,&smallwindow::destroythis);
        while (order==mem[0]||order==mem[1]) {
            order=generator.bounded(10);
        }
        mem[2]=order;
        QPushButton* nature3=smwdw->addbutton();
        nature3->setGeometry(510,80,200,300);
        nature3->setText(scene->character->updiscribe[order]);
        nature3->setFont(font);
        nature3->setStyleSheet("background-color:white;");
        nature3->setFocusPolicy(Qt::NoFocus);
        nature3->show();
        connect(nature3,&QPushButton::clicked,this,&MyView::withoutname3);
        connect(nature3,&QPushButton::clicked,this,&MyView::startscenetimer);
        connect(nature3,&QPushButton::clicked,smwdw,&smallwindow::destroythis);

    }
    void withoutname1(){
        character->meminfo=mem[0];
        character->useup();
    }
    void withoutname2(){
        character->meminfo=mem[1];
        character->useup();
    }
    void withoutname3(){
        character->meminfo=mem[2];
        character->useup();
    }

signals:
    void clickcharacter();


};


#endif // MYVIEW_H
