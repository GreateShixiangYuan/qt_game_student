
#ifndef HOME_H
#define HOME_H


#include<QString>
#include<QObject>
#include<QPixmap>
#include<QPalette>
#include<QTimer>
#include<QPointF>
#include"equipwindow.h"
#include"sharecode.h"
#include"store.h"

class Home:public QGraphicsScene
{
public:
    Home(QObject* parent=nullptr);
    QTimer* timer;
    Jues* c[3];

    QPushButton* store;
    QPushButton* startgame;
    QPushButton* warehouse;
    QPushButton* outgame;
    QLabel* showmoney;

    int* money;
    int* things;//记录装备数量
    Equipment* equipment[6];//初始化装备

    int *clickc;//鼠标点击



    //windows
    EquipWindow* equipwindow;
    Store* storewindow;
    void dealclickstore(){
        storewindow=new Store(nullptr,things,money,equipment);
        storewindow->show();
    }
    void resetshowmoney(){
        showmoney->setText(QString("%1").arg(*money));
    }
    void dealclickcharacter(){
        equipwindow=new EquipWindow(nullptr,c,equipment,*clickc,things,money);
        equipwindow->show();
    }


};

#endif // HOME_H
