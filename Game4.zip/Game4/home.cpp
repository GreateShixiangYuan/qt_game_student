
#include "home.h"

Home::Home(QObject* parent):QGraphicsScene(parent)
{
    things=new int[6];
    for(int i=0;i<6;i++){
        things[i]=0;
    }
    money=new int(1000);
    clickc=new int;


    setSceneRect(0,0,800,600);
    //画地板
    QPixmap pix("D:\\game\\Game4\\cozymapgrid2.jpg");
    QBrush brush(pix);
    setBackgroundBrush(brush);
    for(int i=0;i<14;i++){
        QGraphicsPixmapItem* pixmap=new QGraphicsPixmapItem;
        pixmap->setPixmap(QPixmap("D:\\game\\Game4\\obstacle.jpg"));
        addItem(pixmap);
        pixmap->setPos(i*60-31,0);
        pixmap->setData(ObjectType2,Obsta);
        QGraphicsPixmapItem* pixmap2=new QGraphicsPixmapItem;
        pixmap2->setPixmap(QPixmap("D:\\game\\Game4\\obstacle.jpg"));
        addItem(pixmap2);
        pixmap2->setPos(i*60-31,540);
        pixmap2->setData(ObjectType2,Obsta);
        if(i<9&&i>0){
            QGraphicsPixmapItem* pixmap=new QGraphicsPixmapItem;
            pixmap->setPixmap(QPixmap("D:\\game\\Game4\\obstacle.jpg"));
            addItem(pixmap);
            pixmap->setPos(-30,i*60);
            pixmap->setData(ObjectType2,Obsta);
            if(i!=8){
            QGraphicsPixmapItem* pixmap2=new QGraphicsPixmapItem;
            pixmap2->setPixmap(QPixmap("D:\\game\\Game4\\obstacle.jpg"));
            addItem(pixmap2);

            pixmap2->setPos(750,i*60);
            pixmap2->setData(ObjectType2,Obsta);
            }
        }
    }
    //绘制边界
    QGraphicsPixmapItem* bed1=new QGraphicsPixmapItem;
    bed1->setPixmap(QPixmap("D:\\game\\Game4\\bed.png"));
    addItem(bed1);
    bed1->setPos(30,60);
    bed1->setData(ObjectType2,Obsta);

    QGraphicsPixmapItem* door=new QGraphicsPixmapItem;
    door->setPixmap(QPixmap("D:\\game\\Game4\\door.png"));
    addItem(door);
    door->setPos(750,480);
    door->setData(ObjectType2,Obsta);

    QGraphicsPixmapItem* table=new QGraphicsPixmapItem;
    table->setPixmap(QPixmap("D:\\game\\Game4\\table.png"));
    addItem(table);
    table->setPos(350,250);
    table->setData(ObjectType2,Obsta);

    QGraphicsPixmapItem* chair1=new QGraphicsPixmapItem;
    chair1->setPixmap(QPixmap("D:\\game\\Game4\\chair.png"));
    addItem(chair1);
    chair1->setPos(300,310);
    chair1->setData(ObjectType2,Obsta);

    QGraphicsPixmapItem* chair2=new QGraphicsPixmapItem;
    chair2->setPixmap(QPixmap("D:\\game\\Game4\\chair.png"));
    addItem(chair2);
    chair2->setPos(480,300);
    chair2->setData(ObjectType2,Obsta);

    QGraphicsPixmapItem* chair3=new QGraphicsPixmapItem;
    chair3->setPixmap(QPixmap("D:\\game\\Game4\\chair.png"));
    addItem(chair3);
    chair3->setPos(390,190);
    chair3->setData(ObjectType2,Obsta);

    QGraphicsPixmapItem* chair4=new QGraphicsPixmapItem;
    chair4->setPixmap(QPixmap("D:\\game\\Game4\\chair.png"));
    addItem(chair4);
    chair4->setPos(390,370);
    chair4->setData(ObjectType2,Obsta);

    QGraphicsPixmapItem* shop=new QGraphicsPixmapItem;
    shop->setPixmap(QPixmap("D:\\game\\Game4\\shop.png"));
    addItem(shop);
    shop->setPos(680,60);
    shop->setData(ObjectType2,Obsta);

    QGraphicsPixmapItem* cabinet=new QGraphicsPixmapItem;
    cabinet->setPixmap(QPixmap("D:\\game\\Game4\\cabinet.png"));
    addItem(cabinet);
    cabinet->setPos(35,450);
    cabinet->setData(ObjectType2,Obsta);

//画家具

    timer=new QTimer(this);
    timer->start(50);
    //           0:hp1:def 2:atk3:atksp4:pet 5:skr 6:ske 7:spd//8:hand,9:shoes
    //10 head,11 body,
    int na[12]={ 5000,600,1,10, 400,12, 180,9, 0,0,0,0};
    int na2[12]={8000,1000,1 ,6,  800,8, 230,9, 0,0,0,0};
    int na3[12]={3000,300, 1, 15, 600,25, 150,12,0,0,0,0};
    c[0]=new Jues("D:\\game\\Game4\\character1.png",this,na);
    c[0]->setPos(500,100);
    c[1]=new Jues("D:\\game\\Game4\\character2.png",this,na2);
    c[1]->setPos(200,100);
    c[2]=new Jues("D:\\game\\Game4\\character3.png",this,na3);
    c[2]->setPos(100,400);
//人物

    QFont font("宋体",25,QFont::Bold);
    QPalette palette;
    store=new QPushButton("商店");
    addWidget(store);
    palette.setBrush(QPalette::Button, QPixmap("D:\\game\\Game4\\buttonback2.png").scaled(150,50));
    store->setGeometry(640,5,150,50);
    store->setAutoFillBackground(true);
    store->setPalette(palette);

    store->setFont(font);
    store->setFlat(true);
    store->setFocusPolicy(Qt::NoFocus);

    outgame=new QPushButton("退出游戏");
    addWidget(outgame);
    outgame->setGeometry(10,5,150,50);
    outgame->setAutoFillBackground(true);
    outgame->setPalette(palette);
    outgame->setFont(font);
    outgame->setFlat(true);
    outgame->setFocusPolicy(Qt::NoFocus);


    startgame=new QPushButton("开始探索");
    addWidget(startgame);
    palette.setBrush(QPalette::Button,QPixmap("D:\\game\\Game4\\buttonback3.png").scaled(150,50));
    startgame->setAutoFillBackground(true);
    startgame->setPalette(palette);
    startgame->setGeometry(640,540,150,50);
    startgame->setFont(font);
    startgame->setStyleSheet("color:white;");
    startgame->setFlat(true);
    startgame->setFocusPolicy(Qt::NoFocus);

    //装备
    QPixmap pixmap[6];
    QString name[6];
    int price[6];
    QString introduce[6];
    pixmap[0].load("D:\\game\\Game4\\medicine.png");
    pixmap[1].load("D:\\game\\Game4\\relive.png");
    pixmap[2].load("D:\\game\\Game4\\glove.png");
    pixmap[3].load("D:\\game\\Game4\\shoes.png");
    pixmap[4].load("D:\\game\\Game4\\helmet.png");
    pixmap[5].load("D:\\game\\Game4\\cloth.png");

    name[0]="回血药";
    name[1]="复活丹";
    name[2]="无限手套";
    name[3]="疾步之靴";
    name[4]="头盔";
    name[5]="蔚蓝盔甲";

    price[0]=300;
    price[1]=500;
    price[2]=1000;
    price[3]=530;
    price[4]=800;
    price[5]=1500;

    introduce[0]="立即恢复2000点血";
    introduce[1]="复活一次";
    introduce[2]="加快攻击速度和提高伤害";
    introduce[3]="增大移动速度";
    introduce[4]="提高生命和防御";
    introduce[5]="提高生命、防御和攻击";
    //0:hp 1:def 2:atk 3:atksp 4:pet 5:skr 6:ske 7:spd//8:hand,9:shoes
    //10 head,11 body,
    qreal n[6][8]={{0,0,0,0,0,0,0,0},
                 {0,0,0,0,0,0,0,0},
                 {0,0,0.3,5,1000,25,50,0},
                 {0,0,0,0,0,0,0,4},
                 {1000,1000,0,0,0,0,0,0},
                 {2000,1500,0.3,0,0,10,0,0}};

    for(int i=0;i<6;i++){
        equipment[i]=new Equipment(pixmap[i],name[i],introduce[i],price[i],nullptr,n[i]);
    }

    //金币
    QGraphicsPixmapItem* coin=new QGraphicsPixmapItem(QPixmap("D:\\game\\Game4\\coin.png"));
    addItem(coin);
    coin->setPos(400,5);
    showmoney=new QLabel(QString("%1").arg(*money));
    addWidget(showmoney);
    showmoney->move(440,5);
    showmoney->setStyleSheet("background-color: transparent;font-size: 25px;color:rgb(255,215,0);");




    connect(timer,&QTimer::timeout,this,&Home::advance);
    connect(store,&QPushButton::clicked,this,&Home::dealclickstore);
    connect(timer,&QTimer::timeout,this,&Home::resetshowmoney);
    //初始化角色属性


}

