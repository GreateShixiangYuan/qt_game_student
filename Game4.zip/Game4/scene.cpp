
#include "scene.h"
#include "qpixmapitem.h"
#define size 60
int maxenemy=20;
int nowenemy=10;
qreal w= 1200;
qreal h= 1200;
static QRandomGenerator generator = QRandomGenerator::securelySeeded();
QPointF position(600,600);
QPointF Core;
QPointF move;
int count=0;
qreal nearestdistance=1200;
QPointF nearestdirection(1,0);
QGraphicsItem* nearest=nullptr;
QpixmapItem* weapon;
qreal pai=3.14159;
QList<QGraphicsPixmapItem*> obstacle_;
int nowlr=1;
int nowws=0;

int difficult=1;
int changes=0;

int Dengji=1;
qreal Experience=0;
qreal Explimit=1000;
qreal Hp;
qreal Atk;
qreal Atkspeed;
qreal Speed;
qreal Defense;
qreal Penetration;
qreal Strikerate;
qreal Strikeeffect;

int Attack1;
int Attack2;
int Attack3;
int Attack4;
qreal Xx1=0;
qreal Xx2=0;
qreal Xx3=0;
qreal Xx4=0;

qreal cattack(qreal attack,qreal defense){
    qreal restdefense=defense-Penetration;
    if(restdefense<0){
        restdefense=0;
    }
    qreal restattack=attack*attack/(attack+restdefense);
    if(generator.bounded(100)<Strikerate){
        restattack*=(Strikeeffect/100);
    }
    return restattack*Atk;
}




Scene::Scene(QObject *parent):QGraphicsScene(parent)
{
    nearestdistance=1200;
    nearestdirection=QPointF(1,0);
    nearest=nullptr;
    count=0;
    timer = new QTimer(this);
    connect(timer,&QTimer::timeout,this,&Scene::check);
    connect(timer,&QTimer::timeout,this,&Scene::advance);
    setSceneRect(0,0,w,h);
    QRectF rect1(0, 0, w, 1);
    QRectF rect2(0, 0, 1, h);
    QGraphicsRectItem *rectItemu = new QGraphicsRectItem(rect1);
    QGraphicsRectItem *rectItemd = new QGraphicsRectItem(rect1);
    QGraphicsRectItem *rectIteml = new QGraphicsRectItem(rect2);
    QGraphicsRectItem *rectItemr = new QGraphicsRectItem(rect2);
    rectItemu->setData(ObjectType,BorderType);
    addItem(rectItemu);
    rectItemu->moveBy(0,-1);
    rectItemd->setData(ObjectType,BorderType);
    addItem(rectItemd);
    rectItemd->setPos(0,1200);
    rectIteml->setData(ObjectType,BorderType);
    addItem(rectIteml);
    rectIteml->moveBy(-1,0);
    rectItemr->setData(ObjectType,BorderType);
    addItem(rectItemr);
    rectItemr->setPos(1200,0);
    drawmap();
    character=new Character("",this);
    addItem(character);
    setFocusItem(character);
    setobstacle(14,3);
    setobstacle(5,5);
    setobstacle(4,4);
    setobstacle(7,7);
    setobstacle(7,8);
    setobstacle(8,9);
    setobstacle(13,10);
    setobstacle(12,10);
    setobstacle(5,17);
    setobstacle(2,15);
    setobstacle(3,14);
    update();
}
void Scene::setdifficult(int d){
    difficult=d;
    difficulty=d;
    maxenemy+=5*difficult;
}
void Scene::setweapon(int cha){
    switch (cha) {
    case 0:
        weapon1=new Weapon("D:\\game\\Game4\\red_sword.png",this);
        character->setpix("D:\\game\\Game4\\character1.png");
        character->updiscribe[7]=QString("增加剑气伤害");
        character->updiscribe[8]=QString("增大攻击范围");
        character->updiscribe[9]=QString("增强吸血效果");
        break;
    case 1:
        weapon1=new Weapon2(" ",this);
        character->setpix("D:\\game\\Game4\\character2.png");
        character->updiscribe[7]=QString("增大发射速度");
        character->updiscribe[8]=QString("加快太极球运动");
        character->updiscribe[9]=QString("增大检测范围");
        break;
    case 2:
        weapon1=new Weapon3("D:\\game\\Game4\\bow2.png",this);
        character->setpix("D:\\game\\Game4\\character3.png");
        character->updiscribe[7]=QString("增大发射速度");
        character->updiscribe[8]=QString("加大异能子弹概率");
        character->updiscribe[9]=QString("多发射子弹");
        break;
    default:
        break;
    }    
    move=QPointF(character->width/2,character->height/2);
    Hp=character->hp;
    character->setPos(w/2-character->width/2,h/2-character->height/2);
    position=character->pos();
    Core=position+move;
    character->changes++;
    character->weapon=weapon1;
    weapon=weapon1;
    weapon1->rectc=character->rect;
    //0:hp 1:def 2:atk 3:atksp 4:pet 5:skr 6:ske 7:spd//8:hand,9:shoes
    //10 head,11 body,
}

void Scene::drawmap(){
    for(int i=0;i<20;i++){
        for(int j=0;j<20;j++){
            int ran=generator.bounded(15);
            QPixmap pixmap("D:\\game\\Game4\\mapgrid3.jpg");
            if(ran>7){
                if(ran>12){
                    pixmap.load("D:\\game\\Game4\\mapgrid.jpg");
                }
                else{
                    pixmap.load("D:\\game\\Game4\\mapgrid2.jpg");
                }
            }
            QGraphicsPixmapItem* maptile=new QGraphicsPixmapItem(pixmap);
            addItem(maptile);
            maptile->setPos(i*60,j*60);
            maptile->setFlag(QGraphicsItem::ItemIsMovable, false);
        }
    }
}

void Scene::keyPressEvent(QKeyEvent* event){
    if (event->key() == Qt::Key_W) {
        character->direction.setY(-1);
        character->W=true;
        nowws=-1;
    }
    else if (event->key() == Qt::Key_S) {
        character->direction.setY(1);
        character->S=true;
        nowws=1;
    }
    else if (event->key() == Qt::Key_A) {
        character->direction.setX(-1);
        character->A=true;
        character->type=true;
        nowlr=-1;
    } else if (event->key() == Qt::Key_D) {
        character->direction.setX(1);
        character->D=true;
        character->type=false;
        nowlr=1;

    }
    if (event->key() == Qt::Key_J){
        weapon1->press=true;
    }
    character->makeit1();
    position.setX(character->x());
    position.setY(character->y());
}
void Scene::keyReleaseEvent(QKeyEvent* event){
    // 捕获释放按键事件
    int key = event->key();
    switch (key) {
    case Qt::Key_J:
        weapon1->press=false;
        break;
    case Qt::Key_W:
        character->W=false;
        character->direction.setY(0);
        break;
    case Qt::Key_S:
        character->S=false;
        character->direction.setY(0);
        break;
    case Qt::Key_A:
        character->A=false;
        character->direction.setX(0);
        break;
    case Qt::Key_D:
        character->D=false;
        character->direction.setX(0);
        break;
    default:break;
}
    if(character->direction.x()==0){
        if(character->A){
            character->direction.rx()=-1;
            character->type=true;
            nowlr=-1;
        }
        else if(character->D){
            character->direction.rx()=1;
            character->type=false;
            nowlr=1;
        }
}
    if(character->direction.y()==0){
        if(character->S){
            character->direction.ry()=1;
            nowws=1;

        }
        else if(character->W){
            character->direction.ry()=-1;
            nowws=-1;
        }
    }
    character->makeit1();
}

void Scene::setobstacle(int x,int y){
    QGraphicsPixmapItem* pixmap=new QGraphicsPixmapItem;
    pixmap->setPixmap(QPixmap("D:\\game\\Game4\\obstacle.jpg"));
    addItem(pixmap);
    pixmap->setPos(x*size,y*size);
    pixmap->setData(ObjectType,ObstacleType);
    obstacle.append(pixmap);
    obstacle_.append(pixmap);
}
QPointF Scene::arr(){
    switch (generator.bounded(4)) {
    case 0:
        return QPointF(0,1);
       break;
    case 1:
        return QPointF(0,-1);
        break;
    case 3:
        return QPointF(1,0);
        break;
    case 2:
        return QPointF(-1,0);
        break;
    default:
        return QPointF(0,0);
    }
}

void Scene::check(){
    if(count%25==0){
        emit gothrough1s();
    }
    count++;

    if(count==timelimit*25){
        emit victory();
    }
    if(Experience>=Explimit){
        character->upgrade();
        Experience=0;
        emit upgrade();
    }
    else{
        character->experience=Experience;
    }
    if(character->changes>changes){
        renew();
        changes=character->changes;
    }
    if(Hp<=character->hp){
        character->nowhp=Hp;
    }
    else {
        character->nowhp=character->hp;
        Hp=character->hp;
    }
    if(character->direction!=QPointF(0,0)){
        weapon1->direction=character->direction;
        qreal dx=character->direction.x();
        qreal dy=character->direction.y();
        character->move(character->speed);
        if(character->movable()){
            emit realmove();
        }
        else{
            character->moveback(character->speed);
            int amount=character->movefortime(character->direction,character->speed);
            emit realmove();
            int gap=character->speed-amount;
            if(gap){
                int gap2=character->movefortime(QPointF(dx,0),gap);
                if(gap2){
                    emit realmove();
                }
                else {
                    int gap3=character->movefortime(QPointF(0,dy),gap);
                    if(gap3){
                    emit realmove();
                    }
            }
            }
        }
        position=character->pos();
        Core=position+move;
        weapon1->core=Core;
    }

    if(Hp<=0){
        timer->stop();
        Hp=character->hp;
        emit die();
    }
    if(count%10==0&&nowenemy<maxenemy){
        QpixmapItem* ene;
        if(generator.bounded(10)<7){
            ene=new Enemy("D:\\game\\Game4\\monster1.png",this);
        }
        else{
            ene=new Enemy2(this);
        }
        int x=generator.bounded(4);
        int y=generator.bounded(h-200);
        switch (x) {
        case 0:
            ene->setPos(y+1,5);
            break;
        case 1:
            ene->setPos(y+1,1100);
            break;
        case 2:
            ene->setPos(5,y+1);
            break;
        case 3:
            ene->setPos(1100,y+1);
            break;
        default:
            break;
        }
        addItem(ene);
    }
}
void Scene::renew(){
    Hp=character->nowhp;
    Defense=character->defense;
    Atk=character->atk;
    Penetration=character->penetration;
    Strikerate=character->strikerate;
    Strikeeffect=character->strikerate;
    Attack1=weapon1->attack1;
    Attack2=weapon1->attack2;
    Attack3=weapon1->attack3;
    Attack4=weapon1->attack4;
    Dengji=character->dengji;
    Experience=character->experience;
    Explimit=character->explimit;
    Xx1=weapon1->xx1;
    Xx2=weapon1->xx2;
    Xx3=weapon1->xx3;
    Xx4=weapon1->xx4;
}

bool QpixmapItem::movable(){
    QList<QGraphicsItem*> items = collidingItems();
    for(auto i:items){
        if(i->data(ObjectType) == ObstacleType||i->data(ObjectType) == BorderType)
            return false;
    }
    return true;
}
void QpixmapItem::ifreverse(){
    bool temp=false;
    if(nowlr==1){
        temp=true;
    }
    if(temp!=type){
        type=temp;
        if(!type){
            setPixmap(pixmap_reverse);
        }
        else{
            setPixmap(pixmap);
        }
    }
}
qreal gap(QPointF p1,QPointF p2){
    qreal x=p1.x()-p2.x();
    qreal y=p1.y()-p2.y();
    return qSqrt(x*x+y*y);
}

void Enemy::advance(int phase){
    if(nowhp<=0){
        if(nearest==this){
            nearestdistance=w;
            nearest=nullptr;
        }
        scene->removeItem(this);
        nowenemy--;
        Experience+=100;
        int nm=generator.bounded(20);
        if(nm<4){
            if(nm<2){
            new Crystal1(scene,pos());
            }
            else{
            new Crystal2(scene,pos());
            }
        }
        delete this;
        return;
    }
    qreal gapdistance=gap(pos(),position);
    if(gapdistance<nearestdistance||nearest==this){
        nearestdistance=gapdistance;
        nearest=this;
        nearestdirection.rx()=(x()-position.x())/nearestdistance;
        nearestdirection.ry()=(y()-position.y())/nearestdistance;
    }
    QList<QGraphicsItem*> items = collidingItems();
    if(items.count()){
        foreach (auto item, items) {
            if (item->data(ObjectType) == WeaponType){
                nowhp-=cattack(Attack1,defense);
                Hp+=Attack1*Xx1;
            }
            else if(item->data(ObjectType) == Weapon2Type) {
                nowhp-=cattack(Attack2,defense);
                Hp+=Attack2*Xx2;
             }
            else if(item->data(ObjectType) == Weapon3Type){
                nowhp-=cattack(Attack3,defense);
                Hp+=Attack3*Xx3;
            }
            else if(item->data(ObjectType) == Weapon4Type){
               nowhp-=cattack(Attack4,defense);
               Hp+=attack4*xx4;
               if(!ifcontrol){
                   ifcontrol=true;
                    gapx=x()-item->x();
                   gapy=y()-item->y();

               }
               setPos(item->pos()+QPointF(gapx,gapy));
               return;
            }
            else {
               ifcontrol=false;
            }
        }
    }

    if(count%40==0){
        targeted=false;
        return;
    }
    if(targeted){
        if(qSqrt((destination.x()-x())*(destination.x()-x())+(destination.y()-y())*(destination.y()-y()))<2.5*size){
            targeted=false;
        }
        else{
        QPointF target(pos()+direction*speed);
        setPos(target);
        if(!movable()){
            setPos(pos()-direction*speed);
            destination=pos()+Scene::arr()*20;
        }
        }
    }
    else{
        qreal dx=position.x()-x();
        qreal dy=position.y()-y();
        qreal distance=qSqrt(dx*dx+dy*dy);
        if(distance<=5*size){
            targeted=true;
            destination=position;
            direction.setX(dx/distance);
            direction.setY(dy/distance);
        }
        else{
            if(count%20==0&&!ifcontrol){
                direction=Scene::arr();
            }
            else{
                QPointF target(pos()+direction*speed);
                setPos(target);
                if(!movable())
                {
                    setPos(pos()-2*direction*speed);
                    if(movable())
                    direction*=-1;
                    else{
                    setPos(pos()+direction*speed);
                    }
                }
            }
    }
    }
    if(count%(49-5*difficult)==0){
    shoot();
    }
    bool temp=true;
    if(direction.x()<0){
    temp=false;
    }
    if(temp!=type){
    type=temp;
    if(type){
            setPixmap(pixmap);
    }
    else{
        setPixmap(pixmap_reverse);
    }
    }

}
void Enemy2::advance(int phase){
    if(nowhp<=0){
    if(nearest==this){
        nearestdistance=w;
        nearest=nullptr;
    }
    scene->removeItem(this);
    nowenemy--;
    Experience+=300;

    int nm=generator.bounded(20);
    if(nm<4){
        if(nm<2){
                new Crystal1(scene,pos());
        }
        else{
                new Crystal2(scene,pos());
        }
    }
    delete this;
    return;
    }
    qreal gapdistance=gap(pos(),position);
    if(gapdistance<nearestdistance||nearest==this){
    nearestdistance=gapdistance;
    nearest=this;
    nearestdirection.rx()=(x()-position.x())/nearestdistance;
    nearestdirection.ry()=(y()-position.y())/nearestdistance;
    }
    QList<QGraphicsItem*> items = collidingItems();
    if(items.count()){
    foreach (auto item, items) {
        if (item->data(ObjectType) == WeaponType){
                nowhp-=cattack(Attack1,defense);
                Hp+=Attack1*Xx1;
        }
        else if(item->data(ObjectType) == Weapon2Type) {
                nowhp-=cattack(Attack2,defense);
                Hp+=Attack2*Xx2;
        }
        else if(item->data(ObjectType) == Weapon3Type){
                nowhp-=cattack(Attack3,defense);
                Hp+=Attack3*Xx3;
        }
        else if(item->data(ObjectType) == Weapon4Type){
                nowhp-=cattack(Attack4,defense);
                Hp+=attack4*xx4;
                if(!ifcontrol){
                    ifcontrol=true;
                    gapx=x()-item->x();
                    gapy=y()-item->y();

                }
                setPos(item->pos()+QPointF(gapx,gapy));
                return;
        }
        else {
                ifcontrol=false;
        }
    }
    }

    if(count%40==0){
    targeted=false;
    return;
    }
    if(targeted){
    if(qSqrt((destination.x()-x())*(destination.x()-x())+(destination.y()-y())*(destination.y()-y()))<0.5*size){
        targeted=false;
    }
    else{
        QPointF target(pos()+direction*speed);
        setPos(target);
        if(!movable()){
                setPos(pos()-direction*speed);
                destination=pos()+Scene::arr()*20;
        }
    }
    }
    else{
    qreal dx=position.x()-x();
    qreal dy=position.y()-y();
    qreal distance=qSqrt(dx*dx+dy*dy);
    if(distance<=5*size){
        targeted=true;
        destination=position;
        direction.setX(dx/distance);
        direction.setY(dy/distance);
    }
    else{
        if(count%20==0&&!ifcontrol){
                direction=Scene::arr();
        }
        else{
                QPointF target(pos()+direction*speed);
                setPos(target);
                if(!movable())
                {
                    setPos(pos()-2*direction*speed);
                    if(movable())
                    direction*=-1;
                    else{
                    setPos(pos()+direction*speed);
                    }
                }
        }
    }
    }
    bool temp=true;
    if(direction.x()<0){
    temp=false;
    }
    if(temp!=type){
    type=temp;
    if(type){
        setPixmap(pixmap);
    }
    else{
        setPixmap(pixmap_reverse);
    }
    }

}

void Bullet::advance(int phase){
    if(crash){
    if(crash++==5){
    scene->removeItem(this);
    delete this;
    }
    return;
    }
    QPointF p=mapToScene(0,0)+speed*direction/10;
    QList<QGraphicsItem*> items = collidingItems();
    if(items.count()){
        foreach (auto *item, items) {
        if (item->data(ObjectType) == ObstacleType||item->data(ObjectType) == WeaponType||item->data(ObjectType) == BorderType||item->data(ObjectType) == Weapon2Type||item->data(ObjectType) == Weapon4Type){
                setPixmap(QPixmap("D:\\game\\Game4\\pomp.png"));
                crash=1;
                return;
        }
        else if (item->data(ObjectType) ==CharacterType){
                setPixmap(QPixmap("D:\\game\\Game4\\pomp.png"));
                crash=1;
                Hp-=90000/(300+Defense);
                return;
        }

        }
    }
    setPos(p);
}


int Character::movefortime(QPointF dire,int times){
    int i=0;
    for(;i<times;i++){
        moveBy(dire.x(),dire.y());
        if(!movable()){
        moveBy(-dire.x(),-dire.y());
        break;
        }
    }
    return i;
}
void Character::advance(int phase){
    if(direction.x()>0){
        setPixmap(pixmap);
    }
    if(direction.x()<0){
        setPixmap(pixmap_reverse);
    }
    QList<QGraphicsItem*> items = collidingItems();
    if(items.count()){
        foreach (auto *item, items) {
        if (item->data(ObjectType) ==MonsterType){
                int hurt=250000/(500+defense);
                Hp-=hurt/5;
        }
        else if(item->data(ObjectType) ==Cry1){
                hp+=1000;
                nowhp=hp;
                changes++;
        }
        else if(item->data(ObjectType) ==Cry2){
                atk+=0.1;
                penetration+=100;
                changes++;

        }
        }
    }
}



void Weapon::advance(int phase){
        if(pos()!=Core){
        if(direction==predirection)
            moveBy(Core.x()-x(),Core.y()-y());
        }
        ifreverse();
        QLineF line = QLineF(0, 0, direction.x(), -direction.y());
        qreal angle = line.angle() ;
        qreal dif=-60;
        if(nowlr<0){
        dif=60;
        }
        if(direction!=predirection){
        setPos(core+direction*rectc.width()/2);
        predirection=direction;
        setRotation(angle+dif);
        times=0;
        }
        if(times==10&&ifqi==false){
        QRectF rec=boundingRect();
        qi=new QpixmapItem("D:\\game\\Game4\\qi.png",scene);
        if(nowlr<0){
            qi->setPixmap(qi->pixmap_reverse);
            QPointF top_left=rec.bottomRight();
            QPointF scene_pos = mapToScene(top_left);
            qi->setRotation(angle-180);
            qi->setPos(scene_pos+direction*qi->rect.width());
        }
        else if(nowlr>0){
            QPointF top_left=rec.bottomRight();
            QPointF scene_pos = mapToScene(top_left);
            qi->setRotation(angle);
            qi->setPos(scene_pos);
        }

        qi->setData(ObjectType,Weapon2Type);
        ifqi=true;
        }
        if(times==5&&ifqi==true){
        qi->die();
        qi=nullptr;
        ifqi=false;
        }
        if(times>0){
        setRotation(angle+dif-(24.0+naofweapon[1])*(qAbs(5-times%10)-5)*nowlr);
        times--;
        }
        if(press&&times==0){
        times=10;
        }
}
void Weapon2::advance(int){
    if(rotation1>360){
        rotation1-=360;
    }
    rotation1+=attack1;
    qreal rad=rotation1*3.14/180;
    qreal dx;
    qreal dy;
    qreal dd=3.14/1.5;
    for(int i=0;i<3;i++){
        dx=distance*sin(rad+i*dd);
        dy=distance*cos(rad+i*dd);
        QPointF cor=balls[i]->boundingRect().center();
        balls[i]->setPos(Core+QPointF(dx,dy)-cor);
    }
    if(times>0){
        times--;
    }
    if(press&&times==0){
        if(nearestdistance<=distance+naofweapon[2]){
            shoot(nearestdirection);
        }
        else{
        if(direction==QPointF(0,0))
            shoot(QPointF(1,0));
        else{
            shoot(direction);
        }
        }
        times=naofweapon[0];
    }
}

void Weapon3::shoot(qreal angle){

    for(int i=0;i<naofweapon[2];i++){
    int kind=generator.bounded(50);
    qreal d=generator.bounded(60);
    if(kind+naofweapon[1]<36){
    Bullet3* b=new Bullet3("D:\\game\\Game4\\bullet2.png","D:\\game\\Game4\\explode_4.png",scene,angle+d-30,Core);
        b-> setData(ObjectType, WeaponType);
    }
    else if(kind+naofweapon[1]<46){
        Bullet3* b=new Bullet3("D:\\game\\Game4\\bullet4.png","D:\\game\\Game4\\explode_3.png",scene,angle+d-30,Core);
        b-> setData(ObjectType, Weapon2Type);
    }
    else{
        Bullet3* b=new Bullet3("D:\\game\\Game4\\bullet3.png","D:\\game\\Game4\\explode_2.png",scene,angle+d-30,Core);
        b-> setData(ObjectType, Weapon3Type);
    }
    }
}

void Weapon3::advance(int){
    if(times>0){
        times--;
    }

    if(press&&times==0){
        if(nearestdistance<=distance){
        QLineF line(0,0,nearestdirection.x(),nearestdirection.y());
        rotation1=line.angle();
        }
        else{
        QLineF line(0,0,direction.x(),direction.y());
        rotation1=line.angle();
        }
        shoot(rotation1);
        times=naofweapon[0];
    }
    else if(times==naofweapon[0]-3||times==naofweapon[0]-6||times==naofweapon[0]-9){
        shoot(rotation1);
    }
    setRotation(-rotation1);
    QPointF cor(mapToScene(boundingRect().center()));
    moveBy(Core.x()-cor.x(),Core.y()-cor.y());

}
