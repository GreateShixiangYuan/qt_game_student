
#include "levelwindow.h"

LevelWindow::LevelWindow(QWidget* parent,Scene* scene_):QMainWindow(parent)
{
    //改变scene的difficult,view直接从经两个窗口初始化的scene中读difficult
    scene=scene_;
    resize(800,600);
    setWindowTitle("幸存者游戏");
    setWindowIcon(QIcon("D:\\game\\Game4\\icon.png"));
    QPalette palette;
    palette.setBrush(QPalette::Window,QBrush(QPixmap("D:\\game\\Game4\\selectlevel.jpg")));
    setPalette(palette);
    QFont font("宋体",25,QFont::Bold);

    easy=new QPushButton("简单",this);
    easy->setGeometry(300,40,200,70);
    palette.setBrush(QPalette::Button,QPixmap("D:\\game\\Game4\\buttonback3.png").scaled(200,70));
    easy->setAutoFillBackground(true);
    easy->setPalette(palette);
    easy->setFont(font);
    easy->setStyleSheet("color: yellow;");
    easy->setFlat(true);
    easy->setFocusPolicy(Qt::NoFocus);
    easy->setToolTip("怪物数量少，生存时间短");

   // easy->setStyleSheet("background-color:#CD853F ; color: black;");

    middle=new QPushButton(this);
    middle->setGeometry(300,200,200,70);
    middle->setAutoFillBackground(true);
    middle->setPalette(palette);
    middle->setText("中等");
    middle->setFont(font);
    middle->setStyleSheet("color:#CD853F;");
    middle->setFlat(true);
    middle->setFocusPolicy(Qt::NoFocus);
    middle->setToolTip("怪物数量中等，生存时间中等");
    //
    difficult=new QPushButton(this);
    difficult->setGeometry(300,350,200,70);
    difficult->setAutoFillBackground(true);
    difficult->setPalette(palette);
    difficult->setText("困难");
    difficult->setFont(font);
    difficult->setStyleSheet("color: red;");
    difficult->setFlat(true);
    difficult->setFocusPolicy(Qt::NoFocus);
    difficult->setToolTip("怪物数量多，生存时间长");

    back=new QPushButton(this);
    back->setGeometry(20,530,100,50);
    palette.setBrush(QPalette::Button,QPixmap("D:\\game\\Game4\\buttonback2.png").scaled(100,50));
    back->setAutoFillBackground(true);
    back->setPalette(palette);
    back->setText("返回");
    back->setFont(font);
    back->setStyleSheet("color: black;");
    back->setFlat(true);
    back->setFocusPolicy(Qt::NoFocus);

    connect(easy,&QPushButton::clicked,this,&LevelWindow::setlevel1);
    connect(middle,&QPushButton::clicked,this,&LevelWindow::setlevel2);
    connect(difficult,&QPushButton::clicked,this,&LevelWindow::setlevel3);
    connect(back,&QPushButton::clicked,this,&LevelWindow::dealback);

}

