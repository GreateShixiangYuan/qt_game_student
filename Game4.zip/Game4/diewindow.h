
#ifndef DIEWINDOW_H
#define DIEWINDOW_H




#include <QMainWindow>
#include<QPushButton>

class DieWindow:public QMainWindow
{
public:
    DieWindow(QWidget *parent = nullptr);
    QPushButton* regame;
    QPushButton* end;
signals:
    int level(int);
};


#endif // DIEWINDOW_H
