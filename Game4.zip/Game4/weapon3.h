
#ifndef WEAPON3_H
#define WEAPON3_H


#include"qpixmapitem.h"
#include<QGraphicsScene>
//发射时间，发射道数，夹角
class Weapon3:public QpixmapItem
{
public:
    Weapon3(QString filename,QGraphicsScene*);
    void advance(int);
    void shoot(qreal angle);
    void up1(){
        naofweapon[0]*=0.8;
    }
    void up2(){
        naofweapon[1]+=2;
    }
    void up3(){
        naofweapon[2]+=1;
    }
    void setweaponnature(int dj){
        attack1+=dj*20;
        attack2+=dj*20;
        attack3+=dj*20;
    }
};


#endif // WEAPON3_H
