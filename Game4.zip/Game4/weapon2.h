
#ifndef WEAPON2_H
#define WEAPON2_H



#include"qpixmapitem.h"
#include<QGraphicsScene>
#include"bullet.h"
//发射时间，球运动速度，球攻击范围
//a2ball,a3爆炸,a4
class Weapon2:public QpixmapItem
{
public:
    Weapon2(QString filename,QGraphicsScene*);
    void advance(int);
    void setpos(QPointF);
    void shoot(QPointF);
    void up1(){
        naofweapon[0]*=0.8;
    }
    void up2(){
        attack1+=0.5;
        attack2+=5;
    }
    void up3(){
        naofweapon[2]+=30;
    }
    void setweaponnature(int dj){
        attack2+=dj*10;
        attack3+=dj*100;
    }
};

#endif // WEAPON2_H
