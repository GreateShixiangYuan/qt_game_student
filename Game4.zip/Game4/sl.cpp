
#include "sl.h"

SL::SL(QWidget* parent,Home* home_):QMainWindow(parent)
{
    home=home_;
    state=0;
    resize(800,600);
    setWindowTitle("幸存者游戏");
    setWindowIcon(QIcon("D:\\game\\Game4\\icon.png"));
    QPalette palette;
    palette.setBrush(QPalette::Window,QBrush(QPixmap("D:\\game\\Game4\\weaponselect.jpg")));
    setPalette(palette);
    QFont font("宋体",25,QFont::Bold);
    palette.setBrush(QPalette::Button,QBrush(QPixmap("D:\\game\\Game4\\cell.png")));
    ifstream in_file("D:\\game\\Game4\\save.txt",ios::in|ios::binary);
    for(int i=0;i<6;i++){
        cell[i].setParent(this);
        cell[i].setGeometry(100,10+100*i,600,80);
        cell[i].setPalette(palette);
        cell[i].setAutoFillBackground(true);
        cell[i].setFlat(true);
        cell[i].setFocusPolicy(Qt::NoFocus);
        cell[i].setFont(font);
        cell[i].setStyleSheet("color:white;");
        in_file.seekg(22*4*i);
        // 检查指定位置是否有数据
        char data=0;
        in_file.read(&data, sizeof(char));
        if(data != '\0'){
             cell[i].setText(QString("存档%1").arg(i+1));
        }
    }
    reback=new QPushButton(this);
    reback->setGeometry(760,0,40,40);
    reback->setIcon(QPixmap("D:\\game\\Game4\\cancel.png"));
    reback->setIconSize(QSize(40,40));
    reback->show();
    connect(reback,&QPushButton::clicked,this,&SL::hide);
    connect(cell,&QPushButton::clicked,this,&SL::set1);
    connect(cell+1,&QPushButton::clicked,this,&SL::set2);
    connect(cell+2,&QPushButton::clicked,this,&SL::set3);
    connect(cell+3,&QPushButton::clicked,this,&SL::set4);
    connect(cell+4,&QPushButton::clicked,this,&SL::set5);
    connect(cell+5,&QPushButton::clicked,this,&SL::set6);
}

